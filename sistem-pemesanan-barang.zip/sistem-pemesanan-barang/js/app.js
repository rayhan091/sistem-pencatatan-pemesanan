// app.js - Main JavaScript File
document.addEventListener('DOMContentLoaded', function() {
    console.log('Sistem Pemesanan Barang loaded');
    
    // ===== NOTIFICATION SYSTEM =====
    window.showNotification = function(message, type = 'info') {
        const container = document.getElementById('notificationContainer');
        if (!container) return;
        
        const notification = document.createElement('div');
        notification.className = `alert alert-${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-${getNotificationIcon(type)}"></i>
                <span>${message}</span>
                <button class="close-notification">&times;</button>
            </div>
        `;
        
        container.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => notification.remove(), 300);
        }, 5000);
        
        // Close button
        notification.querySelector('.close-notification').addEventListener('click', function() {
            notification.style.opacity = '0';
            setTimeout(() => notification.remove(), 300);
        });
    };
    
    function getNotificationIcon(type) {
        const icons = {
            'success': 'check-circle',
            'error': 'exclamation-circle',
            'warning': 'exclamation-triangle',
            'info': 'info-circle'
        };
        return icons[type] || 'info-circle';
    }
    
    // ===== FORM VALIDATION =====
    const forms = document.querySelectorAll('form[data-validate]');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const required = form.querySelectorAll('[required]');
            let valid = true;
            
            required.forEach(input => {
                if (!input.value.trim()) {
                    input.classList.add('error');
                    valid = false;
                    
                    // Add error message
                    if (!input.nextElementSibling || !input.nextElementSibling.classList.contains('error-message')) {
                        const error = document.createElement('div');
                        error.className = 'error-message';
                        error.textContent = 'Field ini wajib diisi';
                        error.style.color = '#dc3545';
                        error.style.fontSize = '12px';
                        error.style.marginTop = '5px';
                        input.parentNode.appendChild(error);
                    }
                } else {
                    input.classList.remove('error');
                    const errorMsg = input.nextElementSibling;
                    if (errorMsg && errorMsg.classList.contains('error-message')) {
                        errorMsg.remove();
                    }
                }
            });
            
            if (!valid) {
                e.preventDefault();
                showNotification('Harap lengkapi semua field yang wajib diisi', 'error');
            }
        });
    });
    
    // ===== DELETE CONFIRMATION =====
    const deleteButtons = document.querySelectorAll('.btn-delete, a[href*="delete"]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Apakah Anda yakin ingin menghapus data ini?')) {
                e.preventDefault();
            }
        });
    });
    
    // ===== SEARCH FUNCTIONALITY =====
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                if (this.value.length >= 2 || this.value.length === 0) {
                    const form = this.closest('form');
                    if (form) form.submit();
                }
            }, 500);
        });
    }
    
    // ===== PASSWORD TOGGLE =====
    const togglePasswordBtns = document.querySelectorAll('.toggle-password');
    togglePasswordBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const input = this.previousElementSibling;
            const icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
    
    // ===== AUTO FORMAT CURRENCY =====
    const currencyInputs = document.querySelectorAll('input[data-type="currency"]');
    currencyInputs.forEach(input => {
        input.addEventListener('input', function() {
            // Remove non-numeric characters
            let value = this.value.replace(/[^\d]/g, '');
            
            if (value) {
                // Format as Indonesian currency
                value = parseInt(value);
                this.value = value.toLocaleString('id-ID');
            }
        });
        
        // On blur, ensure it's a proper number
        input.addEventListener('blur', function() {
            let value = this.value.replace(/\./g, '');
            if (value && !isNaN(value)) {
                this.value = parseInt(value).toLocaleString('id-ID');
            }
        });
    });
    
    // ===== AUTO CALCULATE SUBTOTAL =====
    const calculateInputs = document.querySelectorAll('[data-calculate]');
    calculateInputs.forEach(input => {
        input.addEventListener('input', calculateTotal);
    });
    
    function calculateTotal() {
        const rows = document.querySelectorAll('.item-row');
        let total = 0;
        
        rows.forEach(row => {
            const qty = parseFloat(row.querySelector('.quantity').value) || 0;
            const price = parseFloat(row.querySelector('.price').value.replace(/\./g, '')) || 0;
            const subtotal = qty * price;
            
            const subtotalField = row.querySelector('.subtotal');
            if (subtotalField) {
                subtotalField.value = subtotal.toLocaleString('id-ID');
                subtotalField.dataset.value = subtotal;
            }
            
            total += subtotal;
        });
        
        const totalField = document.getElementById('totalAmount');
        if (totalField) {
            totalField.textContent = total.toLocaleString('id-ID');
            totalField.dataset.value = total;
        }
    }
    
    // ===== DATE PICKER ENHANCEMENT =====
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        if (!input.value) {
            input.value = new Date().toISOString().split('T')[0];
        }
    });
    
    // ===== PRINT FUNCTION =====
    window.printPage = function() {
        window.print();
    };
    
    // ===== EXPORT TO CSV =====
    window.exportToCSV = function(tableId, filename = 'data.csv') {
        const table = document.getElementById(tableId);
        if (!table) return;
        
        const rows = table.querySelectorAll('tr');
        const csv = [];
        
        rows.forEach(row => {
            const rowData = [];
            const cells = row.querySelectorAll('th, td');
            
            cells.forEach(cell => {
                // Skip action cells
                if (!cell.classList.contains('no-export')) {
                    rowData.push(`"${cell.textContent.trim().replace(/"/g, '""')}"`);
                }
            });
            
            if (rowData.length > 0) {
                csv.push(rowData.join(','));
            }
        });
        
        const csvContent = csv.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        
        if (navigator.msSaveBlob) {
            navigator.msSaveBlob(blob, filename);
        } else {
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            link.style.display = 'none';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    };
    
    // ===== LOADING INDICATOR =====
    window.showLoading = function() {
        let loader = document.getElementById('loadingOverlay');
        if (!loader) {
            loader = document.createElement('div');
            loader.id = 'loadingOverlay';
            loader.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(255,255,255,0.8);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 9999;
            `;
            loader.innerHTML = `
                <div class="spinner" style="
                    width: 50px;
                    height: 50px;
                    border: 5px solid #f3f3f3;
                    border-top: 5px solid #667eea;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                "></div>
            `;
            document.body.appendChild(loader);
            
            const style = document.createElement('style');
            style.textContent = `
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            `;
            document.head.appendChild(style);
        }
        loader.style.display = 'flex';
    };
    
    window.hideLoading = function() {
        const loader = document.getElementById('loadingOverlay');
        if (loader) {
            loader.style.display = 'none';
        }
    };
    
    // ===== AUTO SAVE FORMS =====
    const autoSaveForms = document.querySelectorAll('form[data-autosave]');
    autoSaveForms.forEach(form => {
        let saveTimeout;
        
        form.addEventListener('input', function() {
            clearTimeout(saveTimeout);
            saveTimeout = setTimeout(() => {
                if (navigator.onLine) {
                    saveFormData(form);
                }
            }, 2000);
        });
        
        // Load saved data on page load
        const savedData = localStorage.getItem(`autosave_${form.id}`);
        if (savedData) {
            const data = JSON.parse(savedData);
            Object.keys(data).forEach(key => {
                const input = form.querySelector(`[name="${key}"]`);
                if (input) {
                    input.value = data[key];
                }
            });
        }
    });
    
    function saveFormData(form) {
        const formData = new FormData(form);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });
        
        localStorage.setItem(`autosave_${form.id}`, JSON.stringify(data));
        showNotification('Perubahan disimpan sementara', 'info');
    }
    
    // ===== REAL-TIME UPDATES (EventSource) =====
    if (window.EventSource) {
        const eventSource = new EventSource('api/updates.php');
        
        eventSource.addEventListener('notification', function(event) {
            const data = JSON.parse(event.data);
            showNotification(data.message, data.type);
        });
        
        eventSource.onerror = function() {
            // Reconnect after 5 seconds
            setTimeout(() => {
                if (eventSource.readyState === EventSource.CLOSED) {
                    window.location.reload();
                }
            }, 50000);
        };
    }
    
    // ===== OFFLINE DETECTION =====
    window.addEventListener('offline', function() {
        showNotification('Anda sedang offline. Perubahan akan disimpan sementara.', 'warning');
    });
    
    window.addEventListener('online', function() {
        showNotification('Koneksi internet telah pulih.', 'success');
        
        // Try to sync saved data
        const forms = document.querySelectorAll('form[data-autosave]');
        forms.forEach(form => {
            const savedData = localStorage.getItem(`autosave_${form.id}`);
            if (savedData) {
                // Send data to server
                fetch(form.action, {
                    method: 'POST',
                    body: JSON.stringify(JSON.parse(savedData)),
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }).then(() => {
                    localStorage.removeItem(`autosave_${form.id}`);
                });
            }
        });
    });
});