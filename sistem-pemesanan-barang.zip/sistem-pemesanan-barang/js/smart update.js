// js/smart-update.js
class SmartUpdateAPI {
    constructor(baseUrl = '') {
        this.baseUrl = baseUrl;
        this.csrfToken = this.getCSRFToken();
    }
    
    getCSRFToken() {
        return document.querySelector('meta[name="csrf-token"]')?.content || '';
    }
    
    async updateOrder(orderId, updates, options = {}) {
        const url = `${this.baseUrl}admin/orders/update_api.php`;
        return this.smartUpdate(url, { id: orderId, ...updates }, options);
    }
    
    async updateProduct(productId, updates, options = {}) {
        const url = `${this.baseUrl}products/update_api.php`;
        return this.smartUpdate(url, { id: productId, ...updates }, options);
    }
    
    async updateGeneric(table, id, updates, options = {}) {
        const url = `${this.baseUrl}api/update.php`;
        return this.smartUpdate(url, {
            table: table,
            id: id,
            updates: updates
        }, options);
    }
    
    async smartUpdate(url, data, options = {}) {
        const {
            checkChanges = true,
            forceUpdate = false,
            showNotifications = true,
            confirmChanges = false
        } = options;
        
        // If force update, skip change detection
        if (forceUpdate) {
            return this.performUpdate(url, data);
        }
        
        // First check if there are actual changes
        if (checkChanges) {
            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-Token': this.csrfToken
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (!result.success) {
                    throw new Error(result.message);
                }
                
                // If no changes were made
                if (!result.updated) {
                    if (showNotifications) {
                        this.showNotification('info', result.message || 'No changes needed');
                    }
                    return result;
                }
                
                // Ask for confirmation if enabled
                if (confirmChanges && result.changes) {
                    const confirmed = await this.confirmChanges(result.changes);
                    if (!confirmed) {
                        return {
                            success: false,
                            message: 'Update cancelled by user',
                            cancelled: true
                        };
                    }
                }
                
                if (showNotifications) {
                    this.showNotification('success', result.message || 'Update successful');
                }
                
                return result;
                
            } catch (error) {
                console.error('Update error:', error);
                
                if (showNotifications) {
                    this.showNotification('error', error.message || 'Update failed');
                }
                
                throw error;
            }
        }
        
        // Skip change detection
        return this.performUpdate(url, data);
    }
    
    async performUpdate(url, data) {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': this.csrfToken
            },
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        return await response.json();
    }
    
    async confirmChanges(changes) {
        return new Promise((resolve) => {
            const changesHtml = Array.isArray(changes) 
                ? changes.map(change => `<li>${change}</li>`).join('')
                : `<li>${changes}</li>`;
            
            const modalHtml = `
                <div class="update-confirm-modal">
                    <div class="modal-content">
                        <h3>Confirm Changes</h3>
                        <p>The following changes will be made:</p>
                        <ul>${changesHtml}</ul>
                        <div class="modal-actions">
                            <button class="btn-confirm">Confirm Update</button>
                            <button class="btn-cancel">Cancel</button>
                        </div>
                    </div>
                </div>
            `;
            
            const modal = document.createElement('div');
            modal.innerHTML = modalHtml;
            document.body.appendChild(modal);
            
            modal.querySelector('.btn-confirm').addEventListener('click', () => {
                modal.remove();
                resolve(true);
            });
            
            modal.querySelector('.btn-cancel').addEventListener('click', () => {
                modal.remove();
                resolve(false);
            });
            
            // Close on background click
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.remove();
                    resolve(false);
                }
            });
        });
    }
    
    showNotification(type, message) {
        if (typeof window.showNotification === 'function') {
            window.showNotification(message, type);
        } else {
            // Fallback notification
            const notification = document.createElement('div');
            notification.className = `alert alert-${type}`;
            notification.textContent = message;
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px;
                border-radius: 5px;
                z-index: 10000;
                background: ${type === 'success' ? '#d4edda' : type === 'error' ? '#f8d7da' : '#d1ecf1'};
                color: ${type === 'success' ? '#155724' : type === 'error' ? '#721c24' : '#0c5460'};
                border: 1px solid ${type === 'success' ? '#c3e6cb' : type === 'error' ? '#f5c6cb' : '#bee5eb'};
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }
    }
    
    // Batch update with change detection
    async batchUpdate(updates, options = {}) {
        const results = [];
        const errors = [];
        
        for (const update of updates) {
            try {
                const result = await this.smartUpdate(update.url, update.data, {
                    ...options,
                    showNotifications: false
                });
                
                results.push({
                    id: update.id,
                    success: result.success,
                    updated: result.updated,
                    message: result.message
                });
                
            } catch (error) {
                errors.push({
                    id: update.id,
                    error: error.message
                });
            }
        }
        
        // Show summary notification
        const updatedCount = results.filter(r => r.updated).length;
        const skippedCount = results.filter(r => r.success && !r.updated).length;
        const errorCount = errors.length;
        
        let summary = [];
        if (updatedCount > 0) summary.push(`${updatedCount} updated`);
        if (skippedCount > 0) summary.push(`${skippedCount} unchanged`);
        if (errorCount > 0) summary.push(`${errorCount} errors`);
        
        this.showNotification(
            errorCount > 0 ? 'warning' : 'success',
            `Batch update complete: ${summary.join(', ')}`
        );
        
        return { results, errors };
    }
}

// Make it globally available
window.SmartUpdateAPI = SmartUpdateAPI;

// Usage Examples
document.addEventListener('DOMContentLoaded', function() {
    const updateAPI = new SmartUpdateAPI('/');
    
    // Example 1: Update order status
    window.updateOrderStatus = async function(orderId, status) {
        try {
            const result = await updateAPI.updateOrder(orderId, {
                status: status,
                updated_by: 'system'
            }, {
                checkChanges: true,
                confirmChanges: true
            });
            
            if (result.updated) {
                console.log('Order updated:', result);
                // Refresh page or update UI
                if (result.data.status === status) {
                    // Update UI element
                    const statusElement = document.querySelector(`.order-${orderId}-status`);
                    if (statusElement) {
                        statusElement.textContent = status;
                        statusElement.className = `status-${status}`;
                    }
                }
            }
            
            return result;
            
        } catch (error) {
            console.error('Failed to update order:', error);
            return { success: false, error: error.message };
        }
    };
    
    // Example 2: Update product stock
    window.updateProductStock = async function(productId, newStock, reason = 'adjustment') {
        try {
            const result = await updateAPI.updateProduct(productId, {
                stock: newStock
            }, {
                checkChanges: true,
                showNotifications: true
            });
            
            if (result.updated) {
                // Update stock display
                const stockElement = document.querySelector(`.product-${productId}-stock`);
                if (stockElement) {
                    stockElement.textContent = newStock;
                    
                    // Add animation for visual feedback
                    stockElement.style.transition = 'all 0.3s';
                    stockElement.style.color = '#28a745';
                    setTimeout(() => {
                        stockElement.style.color = '';
                    }, 1000);
                }
            }
            
            return result;
            
        } catch (error) {
            console.error('Failed to update stock:', error);
            return { success: false, error: error.message };
        }
    };
    
    // Example 3: Batch update multiple products
    window.bulkUpdateProducts = async function(productUpdates) {
        const updates = productUpdates.map(update => ({
            url: 'products/update_api.php',
            id: update.id,
            data: update.changes
        }));
        
        return await updateAPI.batchUpdate(updates, {
            checkChanges: true,
            confirmChanges: true
        });
    };
    
    // Example 4: Auto-save form with change detection
    window.setupAutoSave = function(formId, entityType, entityId) {
        const form = document.getElementById(formId);
        if (!form) return;
        
        let saveTimeout;
        let lastData = {};
        
        // Get initial form data
        const getFormData = () => {
            const data = {};
            const formData = new FormData(form);
            
            formData.forEach((value, key) => {
                if (key && value !== '') {
                    data[key] = value;
                }
            });
            
            return data;
        };
        
        // Check for changes
        const hasChanges = (newData, oldData) => {
            const keys = new Set([...Object.keys(newData), ...Object.keys(oldData)]);
            
            for (const key of keys) {
                const newVal = newData[key];
                const oldVal = oldData[key];
                
                if (newVal !== oldVal) {
                    return true;
                }
            }
            
            return false;
        };
        
        // Auto-save function
        const autoSave = async () => {
            const currentData = getFormData();
            
            if (!hasChanges(currentData, lastData)) {
                console.log('No changes detected, skipping save');
                return;
            }
            
            try {
                let result;
                
                if (entityType === 'order') {
                    result = await updateAPI.updateOrder(entityId, currentData, {
                        checkChanges: true,
                        showNotifications: false
                    });
                } else if (entityType === 'product') {
                    result = await updateAPI.updateProduct(entityId, currentData, {
                        checkChanges: true,
                        showNotifications: false
                    });
                } else {
                    result = await updateAPI.updateGeneric(entityType, entityId, currentData, {
                        checkChanges: true,
                        showNotifications: false
                    });
                }
                
                if (result.success) {
                    if (result.updated) {
                        updateAPI.showNotification('success', 'Changes saved');
                        lastData = currentData; // Update last data
                    } else {
                        updateAPI.showNotification('info', 'No changes to save');
                    }
                }
                
            } catch (error) {
                console.error('Auto-save failed:', error);
                updateAPI.showNotification('error', 'Save failed: ' + error.message);
            }
        };
        
        // Set up event listeners
        form.addEventListener('input', () => {
            clearTimeout(saveTimeout);
            saveTimeout = setTimeout(autoSave, 2000); // Save after 2 seconds idle
        });
        
        form.addEventListener('change', () => {
            clearTimeout(saveTimeout);
            saveTimeout = setTimeout(autoSave, 1000); // Save faster for select changes
        });
        
        // Initialize last data
        lastData = getFormData();
        
        // Show auto-save indicator
        const indicator = document.createElement('div');
        indicator.className = 'auto-save-indicator';
        indicator.textContent = 'Auto-save enabled';
        indicator.style.cssText = `
            position: fixed;
            bottom: 10px;
            right: 10px;
            background: #28a745;
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 12px;
            opacity: 0.7;
            z-index: 999;
        `;
        
        document.body.appendChild(indicator);
        
        console.log(`Auto-save enabled for ${formId}`);
    };
});