<?php
// includes/auth-check.php
require_once '../config/config.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'Silakan login terlebih dahulu!';
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header('Location: ' . BASE_URL . 'login.php');
    exit();
}

// Cek role untuk halaman tertentu
$current_page = basename($_SERVER['PHP_SELF']);
$allowed_pages_by_role = [
    'admin' => ['*'], // Admin bisa akses semua
    'manager' => [
        'dashboard.php', 
        'orders.php', 
        'customers.php', 
        'products.php',
        'reports.php'
    ],
    'staff' => [
        'dashboard.php',
        'orders.php',
        'customers.php'
    ]
];

$user_role = $_SESSION['role'] ?? 'staff';

if ($user_role !== 'admin') {
    if (!in_array($current_page, $allowed_pages_by_role[$user_role]) && 
        !in_array('*', $allowed_pages_by_role[$user_role])) {
        header('HTTP/1.0 403 Forbidden');
        include '403.php';
        exit();
    }
}

// Update last activity time
$_SESSION['last_activity'] = time();

// Auto logout setelah 30 menit tidak aktif
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: ' . BASE_URL . 'login.php?timeout=1');
    exit();
}
?>