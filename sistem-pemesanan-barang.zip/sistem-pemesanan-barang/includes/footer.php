<?php
// includes/footer.php
// Footer Template
?>
    <footer class="main-footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-left">
                    <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?> v<?php echo APP_VERSION; ?></p>
                    <p>Login sebagai: <strong><?php echo isset($_SESSION['full_name']) ? $_SESSION['full_name'] : 'Guest'; ?></strong></p>
                </div>
                <div class="footer-right">
                    <p>Waktu Server: <?php echo date('d/m/Y H:i:s'); ?></p>
                    <p>Status: <span id="connectionStatus" style="color: #28a745;">● Online</span></p>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- JavaScript -->
    <script src="<?php echo BASE_URL; ?>js/app.js"></script>
    <script src="<?php echo BASE_URL; ?>js/notifications.js"></script>
    
    <!-- Page Specific JavaScript -->
    <?php if (isset($page_js)): ?>
        <script src="<?php echo BASE_URL . $page_js; ?>"></script>
    <?php endif; ?>
    
    <script>
        // Online/Offline detection
        function updateConnectionStatus() {
            const statusElement = document.getElementById('connectionStatus');
            if (navigator.onLine) {
                statusElement.textContent = '● Online';
                statusElement.style.color = '#28a745';
            } else {
                statusElement.textContent = '● Offline';
                statusElement.style.color = '#dc3545';
            }
        }
        
        window.addEventListener('online', updateConnectionStatus);
        window.addEventListener('offline', updateConnectionStatus);
        updateConnectionStatus();
        
        // Auto-hide notifications
        setTimeout(() => {
            const notifications = document.querySelectorAll('.notification');
            notifications.forEach(notification => {
                notification.style.animation = 'slideOut 0.3s ease forwards';
                setTimeout(() => notification.remove(), 300);
            });
        }, 5000);
        
        // Session timeout warning
        let warningShown = false;
        const sessionTimeout = <?php echo SESSION_TIMEOUT; ?>;
        const warningTime = sessionTimeout - 300; // 5 minutes before timeout
        
        setInterval(() => {
            const lastActivity = <?php echo isset($_SESSION['last_activity']) ? $_SESSION['last_activity'] : 'null'; ?>;
            if (lastActivity) {
                const now = Math.floor(Date.now() / 1000);
                const timeLeft = sessionTimeout - (now - lastActivity);
                
                if (timeLeft <= warningTime && !warningShown) {
                    warningShown = true;
                    if (notificationSystem) {
                        notificationSystem.show(
                            'Sesi Anda akan berakhir dalam 5 menit. Silakan simpan pekerjaan Anda.',
                            'warning',
                            10000
                        );
                    }
                }
            }
        }, 60000); // Check every minute
    </script>
</body>
</html>