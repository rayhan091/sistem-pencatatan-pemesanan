<?php
// admin/view.php
require_once '../config/config.php';
require_once '../auth-check.php';

$db = new Database();
$page_title = 'Detail Pesanan';

if (!isset($_GET['id'])) {
    header('Location: orders/');
    exit();
}

$order_id = (int)$_GET['id'];

// Get order data
$order = $db->fetchOne("SELECT o.*, c.*, u.full_name as created_by_name
                        FROM orders o 
                        LEFT JOIN customers c ON o.customer_id = c.id 
                        LEFT JOIN users u ON o.created_by = u.id 
                        WHERE o.id = ?", [$order_id]);

if (!$order) {
    $_SESSION['error'] = 'Pesanan tidak ditemukan!';
    header('Location: orders/');
    exit();
}

// Get order items
$items = $db->fetchAll("SELECT oi.*, p.name as product_name, p.sku 
                        FROM order_items oi 
                        JOIN products p ON oi.product_id = p.id 
                        WHERE oi.order_id = ?", [$order_id]);

include '../includes/header.php';
?>

<div class="container">
    <div class="page-header">
        <div class="header-left">
            <h1><i class="fas fa-eye"></i> Detail Pesanan</h1>
            <p>No. Order: <strong><?php echo $order['order_number']; ?></strong></p>
        </div>
        <div class="header-actions">
            <a href="edit.php?id=<?php echo $order_id; ?>" class="btn btn-warning">
                <i class="fas fa-edit"></i> Edit
            </a>
            <a href="orders/print.php?id=<?php echo $order_id; ?>" target="_blank" class="btn btn-primary">
                <i class="fas fa-print"></i> Cetak
            </a>
            <a href="orders/" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
        </div>
    </div>
    
    <!-- Order Status -->
    <div class="card mb-20">
        <div class="card-body">
            <div class="status-display">
                <div class="status-item <?php echo $order['status']; ?>">
                    <div class="status-icon">
                        <?php 
                        $icon = 'fa-clock';
                        if ($order['status'] == 'processing') $icon = 'fa-cogs';
                        if ($order['status'] == 'shipped') $icon = 'fa-shipping-fast';
                        if ($order['status'] == 'delivered') $icon = 'fa-check-circle';
                        if ($order['status'] == 'cancelled') $icon = 'fa-times-circle';
                        ?>
                        <i class="fas <?php echo $icon; ?>"></i>
                    </div>
                    <div class="status-info">
                        <h3>Status Pesanan</h3>
                        <p class="status-text"><?php echo ucfirst($order['status']); ?></p>
                    </div>
                </div>
                
                <div class="status-item <?php echo $order['payment_status']; ?>">
                    <div class="status-icon">
                        <?php 
                        $icon = 'fa-money-bill-wave';
                        if ($order['payment_status'] == 'partial') $icon = 'fa-money-check-alt';
                        if ($order['payment_status'] == 'paid') $icon = 'fa-check-circle';
                        ?>
                        <i class="fas <?php echo $icon; ?>"></i>
                    </div>
                    <div class="status-info">
                        <h3>Status Pembayaran</h3>
                        <p class="status-text"><?php echo ucfirst($order['payment_status']); ?></p>
                    </div>
                </div>
                
                <div class="status-item">
                    <div class="status-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="status-info">
                        <h3>Tanggal Pesanan</h3>
                        <p class="status-text"><?php echo date('d F Y', strtotime($order['order_date'])); ?></p>
                    </div>
                </div>
                
                <div class="status-item">
                    <div class="status-icon">
                        <i class="fas fa-tags"></i>
                    </div>
                    <div class="status-info">
                        <h3>Total Pesanan</h3>
                        <p class="status-text amount">Rp <?php echo number_format($order['grand_total'], 0, ',', '.'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-8">
            <!-- Order Items -->
            <div class="card mb-20">
                <div class="card-header">
                    <h3>Daftar Barang</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Produk</th>
                                    <th>SKU</th>
                                    <th class="text-right">Kuantitas</th>
                                    <th class="text-right">Harga Satuan</th>
                                    <th class="text-right">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($items as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td><?php echo $item['sku']; ?></td>
                                    <td class="text-right"><?php echo $item['quantity']; ?></td>
                                    <td class="text-right">Rp <?php echo number_format($item['unit_price'], 0, ',', '.'); ?></td>
                                    <td class="text-right"><strong>Rp <?php echo number_format($item['subtotal'], 0, ',', '.'); ?></strong></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="4" class="text-right"><strong>Total:</strong></td>
                                    <td class="text-right"><strong>Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></strong></td>
                                </tr>
                                <?php if ($order['discount'] > 0): ?>
                                <tr>
                                    <td colspan="4" class="text-right"><strong>Diskon:</strong></td>
                                    <td class="text-right text-danger">- Rp <?php echo number_format($order['discount'], 0, ',', '.'); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if ($order['tax'] > 0): ?>
                                <tr>
                                    <td colspan="4" class="text-right"><strong>Pajak:</strong></td>
                                    <td class="text-right">+ Rp <?php echo number_format($order['tax'], 0, ',', '.'); ?></td>
                                </tr>
                                <?php endif; ?>
                                <tr>
                                    <td colspan="4" class="text-right"><strong>Grand Total:</strong></td>
                                    <td class="text-right total-amount">Rp <?php echo number_format($order['grand_total'], 0, ',', '.'); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Notes -->
            <?php if ($order['notes']): ?>
            <div class="card mb-20">
                <div class="card-header">
                    <h3><i class="fas fa-sticky-note"></i> Catatan</h3>
                </div>
                <div class="card-body">
                    <p><?php echo nl2br(htmlspecialchars($order['notes'])); ?></p>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="col-md-4">
            <!-- Customer Information -->
            <div class="card mb-20">
                <div class="card-header">
                    <h3><i class="fas fa-user"></i> Informasi Pelanggan</h3>
                </div>
                <div class="card-body">
                    <div class="customer-info">
                        <div class="info-item">
                            <strong>Nama:</strong>
                            <span><?php echo htmlspecialchars($order['name']); ?></span>
                        </div>
                        <?php if ($order['company']): ?>
                        <div class="info-item">
                            <strong>Perusahaan:</strong>
                            <span><?php echo htmlspecialchars($order['company']); ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="info-item">
                            <strong>Email:</strong>
                            <span><?php echo htmlspecialchars($order['email']); ?></span>
                        </div>
                        <div class="info-item">
                            <strong>Telepon:</strong>
                            <span><?php echo htmlspecialchars($order['phone']); ?></span>
                        </div>
                        <?php if ($order['address']): ?>
                        <div class="info-item">
                            <strong>Alamat:</strong>
                            <span><?php echo nl2br(htmlspecialchars($order['address'])); ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="info-item">
                            <strong>Kode Pelanggan:</strong>
                            <span class="badge badge-primary"><?php echo $order['customer_code']; ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Order Information -->
            <div class="card mb-20">
                <div class="card-header">
                    <h3><i class="fas fa-info-circle"></i> Informasi Pesanan</h3>
                </div>
                <div class="card-body">
                    <div class="order-info">
                        <div class="info-item">
                            <strong>No. Order:</strong>
                            <span><?php echo $order['order_number']; ?></span>
                        </div>
                        <div class="info-item">
                            <strong>Tanggal Pesanan:</strong>
                            <span><?php echo date('d/m/Y', strtotime($order['order_date'])); ?></span>
                        </div>
                        <?php if ($order['delivery_date']): ?>
                        <div class="info-item">
                            <strong>Tanggal Pengiriman:</strong>
                            <span><?php echo date('d/m/Y', strtotime($order['delivery_date'])); ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="info-item">
                            <strong>Metode Pembayaran:</strong>
                            <span><?php echo ucfirst($order['payment_method']); ?></span>
                        </div>
                        <div class="info-item">
                            <strong>Dibuat Oleh:</strong>
                            <span><?php echo $order['created_by_name']; ?></span>
                        </div>
                        <div class="info-item">
                            <strong>Dibuat Pada:</strong>
                            <span><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></span>
                        </div>
                        <?php if ($order['updated_at'] != $order['created_at']): ?>
                        <div class="info-item">
                            <strong>Diupdate Pada:</strong>
                            <span><?php echo date('d/m/Y H:i', strtotime($order['updated_at'])); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-bolt"></i> Aksi Cepat</h3>
                </div>
                <div class="card-body">
                    <div class="quick-actions">
                        <a href="orders/print.php?id=<?php echo $order_id; ?>" target="_blank" class="btn btn-block btn-primary mb-10">
                            <i class="fas fa-print"></i> Cetak Invoice
                        </a>
                        <a href="edit.php?id=<?php echo $order_id; ?>" class="btn btn-block btn-warning mb-10">
                            <i class="fas fa-edit"></i> Edit Pesanan
                        </a>
                        <?php if (is_admin()): ?>
                        <a href="orders/delete.php?id=<?php echo $order_id; ?>" 
                           class="btn btn-block btn-danger"
                           onclick="return confirm('Hapus pesanan ini?')">
                            <i class="fas fa-trash"></i> Hapus Pesanan
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.row {
    display: flex;
    flex-wrap: wrap;
    margin: 0 -15px;
}

.col-md-8, .col-md-4 {
    padding: 0 15px;
    box-sizing: border-box;
}

.col-md-8 {
    flex: 0 0 66.666667%;
    max-width: 66.666667%;
}

.col-md-4 {
    flex: 0 0 33.333333%;
    max-width: 33.333333%;
}

@media (max-width: 768px) {
    .col-md-8, .col-md-4 {
        flex: 0 0 100%;
        max-width: 100%;
    }
}

.status-display {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

.status-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 8px;
}

.status-icon {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
}

.status-item.pending .status-icon { background: #ffc107; }
.status-item.processing .status-icon { background: #17a2b8; }
.status-item.shipped .status-icon { background: #007bff; }
.status-item.delivered .status-icon { background: #28a745; }
.status-item.cancelled .status-icon { background: #dc3545; }
.status-item.unpaid .status-icon { background: #dc3545; }
.status-item.partial .status-icon { background: #ffc107; }
.status-item.paid .status-icon { background: #28a745; }

.status-info h3 {
    font-size: 14px;
    color: #666;
    margin-bottom: 5px;
}

.status-text {
    font-size: 18px;
    font-weight: 600;
    color: #333;
}

.status-text.amount {
    color: #28a745;
    font-size: 20px;
}

.customer-info .info-item,
.order-info .info-item {
    margin-bottom: 12px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
}

.customer-info .info-item:last-child,
.order-info .info-item:last-child {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: none;
}

.customer-info strong,
.order-info strong {
    display: block;
    color: #666;
    font-size: 13px;
    margin-bottom: 3px;
}

.customer-info span,
.order-info span {
    display: block;
    color: #333;
    font-size: 14px;
}

.quick-actions .btn {
    margin-bottom: 10px;
}

.quick-actions .btn:last-child {
    margin-bottom: 0;
}

.total-amount {
    font-size: 20px;
    font-weight: 700;
    color: #28a745;
}

.text-right {
    text-align: right;
}

.text-danger {
    color: #dc3545;
}

.mb-10 {
    margin-bottom: 10px;
}
</style>

<script>
// Update order status
function updateOrderStatus(status) {
    if (confirm('Update status pesanan menjadi "' + status + '"?')) {
        fetch('orders/update_status.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                order_id: <?php echo $order_id; ?>,
                status: status
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error: ' + data.message);
            }
        });
    }
}

// Update payment status
function updatePaymentStatus(status) {
    if (confirm('Update status pembayaran menjadi "' + status + '"?')) {
        fetch('orders/update_payment.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                order_id: <?php echo $order_id; ?>,
                status: status
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error: ' + data.message);
            }
        });
    }
}
</script>

<?php include '../includes/footer.php'; ?>