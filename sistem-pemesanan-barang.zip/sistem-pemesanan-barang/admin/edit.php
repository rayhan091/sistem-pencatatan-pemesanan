<?php
// admin/edit.php
require_once '../config/config.php';
require_once '../auth-check.php';

$db = new Database();
$page_title = 'Edit Pesanan';

if (!isset($_GET['id'])) {
    header('Location: orders/');
    exit();
}

$order_id = (int)$_GET['id'];

// Get order data
$order = $db->fetchOne("SELECT o.*, c.name as customer_name 
                        FROM orders o 
                        LEFT JOIN customers c ON o.customer_id = c.id 
                        WHERE o.id = ?", [$order_id]);

if (!$order) {
    $_SESSION['error'] = 'Pesanan tidak ditemukan!';
    header('Location: orders/');
    exit();
}

// Get order items
$items = $db->fetchAll("SELECT oi.*, p.name as product_name, p.sku, p.stock 
                        FROM order_items oi 
                        JOIN products p ON oi.product_id = p.id 
                        WHERE oi.order_id = ?", [$order_id]);

// Get customers and products
$customers = $db->fetchAll("SELECT id, name, customer_code FROM customers WHERE status = 'active' ORDER BY name");
$products = $db->fetchAll("SELECT id, name, sku, price, stock FROM products WHERE status = 'active' ORDER BY name");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $db->beginTransaction();
        
        // Update order
        $db->update('orders', [
            'customer_id' => $_POST['customer_id'],
            'order_date' => $_POST['order_date'],
            'delivery_date' => $_POST['delivery_date'] ?: null,
            'status' => $_POST['status'],
            'payment_status' => $_POST['payment_status'],
            'payment_method' => $_POST['payment_method'],
            'notes' => $_POST['notes'] ?: null,
            'updated_at' => date('Y-m-d H:i:s')
        ], 'id = ?', [$order_id]);
        
        // Update items
        $items_data = json_decode($_POST['items'], true);
        
        // Delete existing items
        $db->delete('order_items', 'order_id = ?', [$order_id]);
        
        // Insert updated items
        foreach ($items_data as $item) {
            $db->insert('order_items', [
                'order_id' => $order_id,
                'product_id' => $item['product_id'],
                'quantity' => $item['quantity'],
                'unit_price' => $item['price']
            ]);
        }
        
        $db->commit();
        
        $_SESSION['success'] = 'Pesanan berhasil diperbarui!';
        header('Location: orders/view.php?id=' . $order_id);
        exit();
        
    } catch (Exception $e) {
        $db->rollback();
        $error = 'Error: ' . $e->getMessage();
    }
}

include '../includes/header.php';
?>

<div class="container">
    <div class="page-header">
        <h1><i class="fas fa-edit"></i> Edit Pesanan</h1>
        <p>No. Order: <strong><?php echo $order['order_number']; ?></strong></p>
    </div>
    
    <?php if (isset($error)): ?>
    <div class="alert alert-error">
        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
    </div>
    <?php endif; ?>
    
    <form method="POST" id="orderForm">
        <div class="card mb-20">
            <div class="card-header">
                <h3>Informasi Pesanan</h3>
            </div>
            <div class="card-body">
                <div class="form-row">
                    <div class="form-group">
                        <label>Pelanggan *</label>
                        <select name="customer_id" class="form-control" required>
                            <option value="">Pilih Pelanggan</option>
                            <?php foreach ($customers as $customer): ?>
                            <option value="<?php echo $customer['id']; ?>" 
                                <?php echo $customer['id'] == $order['customer_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($customer['name'] . ' (' . $customer['customer_code'] . ')'); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Tanggal Pesanan *</label>
                        <input type="date" name="order_date" 
                               value="<?php echo $order['order_date']; ?>" 
                               class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Tanggal Pengiriman</label>
                        <input type="date" name="delivery_date" 
                               value="<?php echo $order['delivery_date']; ?>" 
                               class="form-control">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Status Pesanan</label>
                        <select name="status" class="form-control">
                            <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="processing" <?php echo $order['status'] == 'processing' ? 'selected' : ''; ?>>Processing</option>
                            <option value="shipped" <?php echo $order['status'] == 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                            <option value="delivered" <?php echo $order['status'] == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                            <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Status Pembayaran</label>
                        <select name="payment_status" class="form-control">
                            <option value="unpaid" <?php echo $order['payment_status'] == 'unpaid' ? 'selected' : ''; ?>>Unpaid</option>
                            <option value="partial" <?php echo $order['payment_status'] == 'partial' ? 'selected' : ''; ?>>Partial</option>
                            <option value="paid" <?php echo $order['payment_status'] == 'paid' ? 'selected' : ''; ?>>Paid</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Metode Pembayaran</label>
                        <select name="payment_method" class="form-control">
                            <option value="cash" <?php echo $order['payment_method'] == 'cash' ? 'selected' : ''; ?>>Cash</option>
                            <option value="transfer" <?php echo $order['payment_method'] == 'transfer' ? 'selected' : ''; ?>>Transfer</option>
                            <option value="credit" <?php echo $order['payment_method'] == 'credit' ? 'selected' : ''; ?>>Credit</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Catatan</label>
                    <textarea name="notes" class="form-control" rows="3"><?php echo htmlspecialchars($order['notes'] ?? ''); ?></textarea>
                </div>
            </div>
        </div>
        
        <!-- Order Items -->
        <div class="card mb-20">
            <div class="card-header">
                <h3>Daftar Barang</h3>
                <button type="button" class="btn btn-sm btn-primary" onclick="addItem()">
                    <i class="fas fa-plus"></i> Tambah Barang
                </button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="data-table" id="itemsTable">
                        <thead>
                            <tr>
                                <th width="50">#</th>
                                <th>Produk</th>
                                <th width="120">Kuantitas</th>
                                <th width="150">Harga Satuan</th>
                                <th width="150">Subtotal</th>
                                <th width="80">Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="itemsBody">
                            <!-- Items will be loaded by JavaScript -->
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-right"><strong>Total:</strong></td>
                                <td id="totalAmount">Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-right"><strong>Diskon:</strong></td>
                                <td>
                                    <input type="number" name="discount" id="discount" 
                                           value="<?php echo $order['discount']; ?>" min="0" 
                                           class="form-control" oninput="calculateTotal()">
                                </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-right"><strong>Pajak:</strong></td>
                                <td>
                                    <input type="number" name="tax" id="tax" 
                                           value="<?php echo $order['tax']; ?>" min="0" 
                                           class="form-control" oninput="calculateTotal()">
                                </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-right"><strong>Grand Total:</strong></td>
                                <td id="grandTotal">Rp <?php echo number_format($order['grand_total'], 0, ',', '.'); ?></td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <input type="hidden" name="items" id="itemsData" 
                       value='<?php echo json_encode($items); ?>'>
            </div>
        </div>
        
        <div class="form-actions">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="fas fa-save"></i> Update Pesanan
            </button>
            <a href="orders/view.php?id=<?php echo $order_id; ?>" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>

<script>
const products = <?php echo json_encode($products); ?>;
const existingItems = <?php echo json_encode($items); ?>;
let itemCount = 0;

function addItem(product = null) {
    itemCount++;
    const tbody = document.getElementById('itemsBody');
    const row = document.createElement('tr');
    row.className = 'item-row';
    row.id = 'item-' + itemCount;
    
    const productOptions = products.map(p => 
        `<option value="${p.id}" data-price="${p.price}" data-stock="${p.stock}">
            ${p.name} (${p.sku}) - Stock: ${p.stock}
        </option>`
    ).join('');
    
    row.innerHTML = `
        <td>${itemCount}</td>
        <td>
            <select class="form-control product-select" onchange="updatePrice(${itemCount})" required>
                <option value="">Pilih Produk</option>
                ${productOptions}
            </select>
        </td>
        <td>
            <input type="number" class="form-control quantity" value="1" min="1" 
                   oninput="updateSubtotal(${itemCount})" required>
        </td>
        <td>
            <input type="number" class="form-control price" 
                   data-type="currency" oninput="updateSubtotal(${itemCount})">
        </td>
        <td>
            <input type="text" class="form-control subtotal" readonly>
        </td>
        <td>
            <button type="button" class="btn btn-sm btn-danger" onclick="removeItem(${itemCount})">
                <i class="fas fa-times"></i>
            </button>
        </td>
    `;
    
    tbody.appendChild(row);
    
    // If product is pre-selected
    if (product) {
        const select = row.querySelector('.product-select');
        select.value = product.product_id || product.id;
        updatePrice(itemCount);
        
        if (product.quantity) {
            row.querySelector('.quantity').value = product.quantity;
        }
        
        if (product.unit_price) {
            row.querySelector('.price').value = product.unit_price;
        }
        
        updateSubtotal(itemCount);
    }
    
    updateItemsData();
}

function loadExistingItems() {
    existingItems.forEach(item => {
        addItem({
            product_id: item.product_id,
            quantity: item.quantity,
            unit_price: item.unit_price
        });
    });
}

// Load existing items on page load
document.addEventListener('DOMContentLoaded', function() {
    loadExistingItems();
    calculateTotal();
});

// Other functions same as create.php
function removeItem(id) {
    const row = document.getElementById('item-' + id);
    if (row) {
        row.remove();
        updateItemsData();
        calculateTotal();
    }
}

function updatePrice(itemId) {
    const row = document.getElementById('item-' + itemId);
    const select = row.querySelector('.product-select');
    const priceInput = row.querySelector('.price');
    const quantityInput = row.querySelector('.quantity');
    
    if (select.value) {
        const selectedOption = select.options[select.selectedIndex];
        const price = selectedOption.dataset.price;
        const stock = parseInt(selectedOption.dataset.stock);
        
        priceInput.value = price;
        quantityInput.max = stock;
        
        if (parseInt(quantityInput.value) > stock) {
            quantityInput.value = stock;
        }
        
        updateSubtotal(itemId);
    } else {
        priceInput.value = '';
        updateSubtotal(itemId);
    }
}

function updateSubtotal(itemId) {
    const row = document.getElementById('item-' + itemId);
    const quantity = parseInt(row.querySelector('.quantity').value) || 0;
    const price = parseInt(row.querySelector('.price').value) || 0;
    const subtotal = quantity * price;
    
    row.querySelector('.subtotal').value = formatCurrency(subtotal);
    calculateTotal();
    updateItemsData();
}

function calculateTotal() {
    let total = 0;
    const subtotalInputs = document.querySelectorAll('.subtotal');
    
    subtotalInputs.forEach(input => {
        const value = parseInt(input.value.replace(/\./g, '')) || 0;
        total += value;
    });
    
    const discount = parseInt(document.getElementById('discount').value) || 0;
    const tax = parseInt(document.getElementById('tax').value) || 0;
    const grandTotal = total - discount + tax;
    
    document.getElementById('totalAmount').textContent = formatCurrency(total);
    document.getElementById('grandTotal').textContent = formatCurrency(grandTotal);
}

function updateItemsData() {
    const items = [];
    const rows = document.querySelectorAll('.item-row');
    
    rows.forEach(row => {
        const select = row.querySelector('.product-select');
        const quantity = row.querySelector('.quantity').value;
        const price = row.querySelector('.price').value;
        
        if (select.value && quantity && price) {
            items.push({
                product_id: select.value,
                quantity: parseInt(quantity),
                price: parseInt(price)
            });
        }
    });
    
    document.getElementById('itemsData').value = JSON.stringify(items);
}

function formatCurrency(amount) {
    return 'Rp ' + amount.toLocaleString('id-ID');
}

// Form validation
document.getElementById('orderForm').addEventListener('submit', function(e) {
    const items = JSON.parse(document.getElementById('itemsData').value || '[]');
    
    if (items.length === 0) {
        e.preventDefault();
        alert('Pesanan harus memiliki minimal satu barang!');
        return false;
    }
    
    return true;
});
</script>

<?php include '../includes/footer.php'; ?>