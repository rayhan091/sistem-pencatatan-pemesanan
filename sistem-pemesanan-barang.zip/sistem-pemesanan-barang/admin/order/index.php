<?php
// admin/orders/index.php
require_once '../../config/config.php';
require_once '../../auth-check.php';

$db = new Database();
$page_title = 'Daftar Pesanan';

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Search and filter
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// Build WHERE clause
$where = [];
$params = [];

if ($search) {
    $where[] = "(o.order_number LIKE ? OR c.name LIKE ?)";
    $search_term = "%$search%";
    array_push($params, $search_term, $search_term);
}

if ($status && $status !== 'all') {
    $where[] = "o.status = ?";
    $params[] = $status;
}

if ($date_from) {
    $where[] = "o.order_date >= ?";
    $params[] = $date_from;
}

if ($date_to) {
    $where[] = "o.order_date <= ?";
    $params[] = $date_to;
}

$where_clause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Get total count
$count_query = "SELECT COUNT(DISTINCT o.id) as total 
                FROM orders o 
                LEFT JOIN customers c ON o.customer_id = c.id 
                LEFT JOIN order_items oi ON o.id = oi.order_id 
                $where_clause";
$count_result = $db->fetchOne($count_query, $params);
$total_orders = $count_result['total'] ?? 0;
$total_pages = ceil($total_orders / $limit);

// Get orders
$query = "SELECT o.*, 
                 c.name as customer_name,
                 COUNT(oi.id) as item_count,
                 SUM(oi.subtotal) as total_amount,
                 u.full_name as created_by_name
          FROM orders o 
          LEFT JOIN customers c ON o.customer_id = c.id 
          LEFT JOIN order_items oi ON o.id = oi.order_id 
          LEFT JOIN users u ON o.created_by = u.id 
          $where_clause 
          GROUP BY o.id 
          ORDER BY o.created_at DESC 
          LIMIT $limit OFFSET $offset";

$orders = $db->fetchAll($query, $params);

include '../../includes/header.php';
?>

<div class="container">
    <div class="page-header">
        <h1><i class="fas fa-shopping-cart"></i> Daftar Pesanan</h1>
        <div class="header-actions">
            <a href="create.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Pesanan Baru
            </a>
        </div>
    </div>

    <!-- Filter Card -->
    <div class="card mb-20">
        <div class="card-body">
            <form method="GET" class="filter-form">
                <div class="form-row">
                    <div class="form-group">
                        <label>Pencarian</label>
                        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                               placeholder="No. Order atau Nama Pelanggan">
                    </div>
                    
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="all">Semua Status</option>
                            <option value="pending" <?php echo $status == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="processing" <?php echo $status == 'processing' ? 'selected' : ''; ?>>Processing</option>
                            <option value="shipped" <?php echo $status == 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                            <option value="delivered" <?php echo $status == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                            <option value="cancelled" <?php echo $status == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Dari Tanggal</label>
                        <input type="date" name="date_from" value="<?php echo $date_from; ?>" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label>Sampai Tanggal</label>
                        <input type="date" name="date_to" value="<?php echo $date_to; ?>" class="form-control">
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                    <a href="?" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Orders Table -->
    <div class="card">
        <div class="card-header">
            <h3>Data Pesanan (<?php echo $total_orders; ?>)</h3>
            <div class="table-actions">
                <select id="bulkAction" class="form-control">
                    <option value="">Aksi Massal</option>
                    <option value="print">Cetak Terpilih</option>
                    <option value="export">Export CSV</option>
                    <?php if (is_admin()): ?>
                    <option value="delete">Hapus Terpilih</option>
                    <?php endif; ?>
                </select>
                <button class="btn btn-sm btn-primary" onclick="applyBulkAction()">Terapkan</button>
            </div>
        </div>
        
        <div class="card-body">
            <?php if (empty($orders)): ?>
            <div class="empty-state text-center">
                <i class="fas fa-shopping-cart fa-3x text-muted mb-20"></i>
                <h3>Tidak ada pesanan</h3>
                <p class="text-muted">Belum ada pesanan yang dibuat.</p>
                <a href="create.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Buat Pesanan Pertama
                </a>
            </div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="data-table" id="ordersTable">
                    <thead>
                        <tr>
                            <th width="50">
                                <input type="checkbox" id="selectAll" onchange="toggleSelectAll()">
                            </th>
                            <th>No. Order</th>
                            <th>Pelanggan</th>
                            <th>Tanggal</th>
                            <th>Items</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Pembayaran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): 
                            $status_class = 'badge-secondary';
                            switch($order['status']) {
                                case 'pending': $status_class = 'badge-warning'; break;
                                case 'processing': $status_class = 'badge-info'; break;
                                case 'shipped': $status_class = 'badge-primary'; break;
                                case 'delivered': $status_class = 'badge-success'; break;
                                case 'cancelled': $status_class = 'badge-danger'; break;
                            }
                            
                            $payment_class = 'badge-secondary';
                            switch($order['payment_status']) {
                                case 'paid': $payment_class = 'badge-success'; break;
                                case 'partial': $payment_class = 'badge-warning'; break;
                                case 'unpaid': $payment_class = 'badge-danger'; break;
                            }
                        ?>
                        <tr>
                            <td>
                                <input type="checkbox" class="order-checkbox" value="<?php echo $order['id']; ?>">
                            </td>
                            <td>
                                <a href="view.php?id=<?php echo $order['id']; ?>" class="text-primary">
                                    <strong><?php echo $order['order_number']; ?></strong>
                                </a>
                            </td>
                            <td><?php echo htmlspecialchars($order['customer_name'] ?? '-'); ?></td>
                            <td><?php echo date('d/m/Y', strtotime($order['order_date'])); ?></td>
                            <td><?php echo $order['item_count']; ?></td>
                            <td><strong>Rp <?php echo number_format($order['grand_total'], 0, ',', '.'); ?></strong></td>
                            <td>
                                <span class="badge <?php echo $status_class; ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge <?php echo $payment_class; ?>">
                                    <?php echo ucfirst($order['payment_status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="view.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-info" title="Lihat">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="edit.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="print.php?id=<?php echo $order['id']; ?>" target="_blank" class="btn btn-sm btn-primary" title="Cetak">
                                        <i class="fas fa-print"></i>
                                    </a>
                                    <?php if (is_admin()): ?>
                                    <a href="delete.php?id=<?php echo $order['id']; ?>" 
                                       class="btn btn-sm btn-danger" 
                                       title="Hapus"
                                       onclick="return confirm('Hapus pesanan ini?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <nav class="pagination mt-20">
                <ul class="pagination-list">
                    <?php if ($page > 1): ?>
                    <li>
                        <a href="?page=<?php echo $page-1; ?>&<?php echo http_build_query($_GET); ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="<?php echo $i == $page ? 'active' : ''; ?>">
                        <a href="?page=<?php echo $i; ?>&<?php echo http_build_query($_GET); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                    <li>
                        <a href="?page=<?php echo $page+1; ?>&<?php echo http_build_query($_GET); ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                <div class="pagination-info">
                    Menampilkan <?php echo min($limit, count($orders)); ?> dari <?php echo $total_orders; ?> pesanan
                </div>
            </nav>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.filter-form .form-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-bottom: 15px;
}

.form-actions {
    display: flex;
    gap: 10px;
}

.table-actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

.pagination {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #eee;
}

.pagination-list {
    display: flex;
    gap: 5px;
    list-style: none;
    padding: 0;
}

.pagination-list li a {
    display: block;
    padding: 8px 12px;
    background: #f8f9fa;
    border-radius: 4px;
    text-decoration: none;
    color: #333;
    transition: all 0.3s;
}

.pagination-list li.active a {
    background: #667eea;
    color: white;
}

.pagination-list li a:hover {
    background: #e9ecef;
}

.pagination-info {
    color: #666;
    font-size: 14px;
}

.btn-group {
    display: flex;
    gap: 5px;
}

.btn-group .btn-sm {
    padding: 5px 8px;
    font-size: 12px;
}

.empty-state {
    padding: 40px 20px;
    text-align: center;
}

.empty-state i {
    margin-bottom: 15px;
    opacity: 0.5;
}

.empty-state h3 {
    margin-bottom: 10px;
    color: #666;
}
</style>

<script>
function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.order-checkbox');
    checkboxes.forEach(cb => cb.checked = selectAll.checked);
}

function getSelectedOrders() {
    const selected = [];
    document.querySelectorAll('.order-checkbox:checked').forEach(cb => {
        selected.push(cb.value);
    });
    return selected;
}

function applyBulkAction() {
    const action = document.getElementById('bulkAction').value;
    const selected = getSelectedOrders();
    
    if (selected.length === 0) {
        alert('Pilih pesanan terlebih dahulu!');
        return;
    }
    
    switch(action) {
        case 'print':
            window.open('print.php?ids=' + selected.join(','), '_blank');
            break;
            
        case 'export':
            exportToCSV('ordersTable', 'pesanan_' + new Date().toISOString().split('T')[0] + '.csv');
            break;
            
        case 'delete':
            if (confirm('Hapus ' + selected.length + ' pesanan terpilih?')) {
                // Implement bulk delete via AJAX
                fetch('bulk_delete.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ids: selected})
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Terjadi kesalahan: ' + error);
                });
            }
            break;
    }
}

// Add keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl + A to select all
    if (e.ctrlKey && e.key === 'a') {
        e.preventDefault();
        document.getElementById('selectAll').checked = !document.getElementById('selectAll').checked;
        toggleSelectAll();
    }
    
    // Delete selected
    if (e.key === 'Delete') {
        const selected = getSelectedOrders();
        if (selected.length > 0) {
            if (confirm('Hapus ' + selected.length + ' pesanan terpilih?')) {
                // Call delete function
            }
        }
    }
});
</script>

<?php include '../../includes/footer.php'; ?>