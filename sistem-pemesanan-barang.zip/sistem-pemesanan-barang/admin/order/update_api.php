<?php
// admin/orders/update_api.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, PUT, PATCH');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../../config/config.php';

// Cek autentikasi
if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$db = new Database();
$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'POST' || $method == 'PUT' || $method == 'PATCH') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['id'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Order ID is required']);
        exit();
    }
    
    $order_id = (int)$data['id'];
    
    // Get current order data
    $current_order = $db->fetchOne("SELECT * FROM orders WHERE id = ?", [$order_id]);
    
    if (!$current_order) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit();
    }
    
    // Define allowed fields to update
    $allowed_fields = [
        'customer_id', 'order_date', 'delivery_date', 'status', 
        'payment_status', 'payment_method', 'notes', 'discount', 'tax'
    ];
    
    // Prepare update data
    $update_data = [];
    $has_changes = false;
    
    foreach ($allowed_fields as $field) {
        if (isset($data[$field])) {
            $new_value = $data[$field];
            $current_value = $current_order[$field];
            
            // Check if value is different
            if ($new_value != $current_value) {
                $update_data[$field] = $new_value;
                $has_changes = true;
            }
        }
    }
    
    // If no changes, return success without updating
    if (!$has_changes) {
        echo json_encode([
            'success' => true,
            'message' => 'No changes detected. Update skipped.',
            'data' => $current_order,
            'updated' => false
        ]);
        exit();
    }
    
    try {
        $db->beginTransaction();
        
        // Add updated_at timestamp
        $update_data['updated_at'] = date('Y-m-d H:i:s');
        
        // Update order
        $affected_rows = $db->update('orders', $update_data, 'id = ?', [$order_id]);
        
        if ($affected_rows > 0) {
            // Get updated order data
            $updated_order = $db->fetchOne("SELECT * FROM orders WHERE id = ?", [$order_id]);
            
            // Log activity
            $changes = [];
            foreach ($update_data as $field => $value) {
                if ($field != 'updated_at') {
                    $changes[] = $field . ': ' . $current_order[$field] . ' → ' . $value;
                }
            }
            
            $db->insert('activity_logs', [
                'user_id' => $_SESSION['user_id'],
                'action' => 'order_update',
                'description' => 'Updated order #' . $order_id . '. Changes: ' . implode(', ', $changes),
                'ip_address' => $_SERVER['REMOTE_ADDR'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT']
            ]);
            
            $db->commit();
            
            echo json_encode([
                'success' => true,
                'message' => 'Order updated successfully',
                'data' => $updated_order,
                'updated' => true,
                'changes' => $changes
            ]);
            
        } else {
            $db->rollback();
            echo json_encode([
                'success' => false,
                'message' => 'No rows affected',
                'updated' => false
            ]);
        }
        
    } catch (Exception $e) {
        $db->rollback();
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Update failed: ' . $e->getMessage(),
            'updated' => false
        ]);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>