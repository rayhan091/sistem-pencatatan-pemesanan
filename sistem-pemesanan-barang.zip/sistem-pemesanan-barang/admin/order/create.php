<?php
// admin/orders/create.php
require_once '../../config/config.php';
require_once '../../auth-check.php';

$db = new Database();
$page_title = 'Buat Pesanan Baru';

// Get customers for dropdown
$customers = $db->fetchAll("SELECT id, name, customer_code FROM customers WHERE status = 'active' ORDER BY name");

// Get products for dropdown
$products = $db->fetchAll("SELECT id, name, sku, price, stock FROM products WHERE status = 'active' AND stock > 0 ORDER BY name");

// Generate order number
$order_number = generate_order_number();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $db->beginTransaction();
        
        // Get form data
        $customer_id = $_POST['customer_id'];
        $order_date = $_POST['order_date'];
        $delivery_date = $_POST['delivery_date'] ?: null;
        $status = $_POST['status'];
        $payment_status = $_POST['payment_status'];
        $payment_method = $_POST['payment_method'];
        $notes = $_POST['notes'] ?: null;
        
        // Calculate totals from items
        $items = json_decode($_POST['items'], true);
        $total_amount = 0;
        
        foreach ($items as $item) {
            $subtotal = $item['quantity'] * $item['price'];
            $total_amount += $subtotal;
        }
        
        $discount = $_POST['discount'] ?: 0;
        $tax = $_POST['tax'] ?: 0;
        $grand_total = $total_amount - $discount + $tax;
        
        // Insert order
        $order_id = $db->insert('orders', [
            'order_number' => $order_number,
            'customer_id' => $customer_id,
            'order_date' => $order_date,
            'delivery_date' => $delivery_date,
            'total_amount' => $total_amount,
            'discount' => $discount,
            'tax' => $tax,
            'grand_total' => $grand_total,
            'status' => $status,
            'payment_status' => $payment_status,
            'payment_method' => $payment_method,
            'notes' => $notes,
            'created_by' => $_SESSION['user_id']
        ]);
        
        // Insert order items
        foreach ($items as $item) {
            $db->insert('order_items', [
                'order_id' => $order_id,
                'product_id' => $item['product_id'],
                'quantity' => $item['quantity'],
                'unit_price' => $item['price']
            ]);
            
            // Update product stock
            $db->update('products', 
                ['stock' => $item['stock'] - $item['quantity']], 
                'id = ?', 
                [$item['product_id']]
            );
        }
        
        $db->commit();
        
        $_SESSION['success'] = 'Pesanan berhasil dibuat!';
        header('Location: view.php?id=' . $order_id);
        exit();
        
    } catch (Exception $e) {
        $db->rollback();
        $error = 'Error: ' . $e->getMessage();
    }
}

include '../../includes/header.php';
?>

<div class="container">
    <div class="page-header">
        <h1><i class="fas fa-plus-circle"></i> Buat Pesanan Baru</h1>
        <p>No. Order: <strong><?php echo $order_number; ?></strong></p>
    </div>
    
    <?php if (isset($error)): ?>
    <div class="alert alert-error">
        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
    </div>
    <?php endif; ?>
    
    <form method="POST" id="orderForm">
        <div class="card mb-20">
            <div class="card-header">
                <h3>Informasi Pesanan</h3>
            </div>
            <div class="card-body">
                <div class="form-row">
                    <div class="form-group">
                        <label>Pelanggan *</label>
                        <select name="customer_id" class="form-control" required>
                            <option value="">Pilih Pelanggan</option>
                            <?php foreach ($customers as $customer): ?>
                            <option value="<?php echo $customer['id']; ?>">
                                <?php echo htmlspecialchars($customer['name'] . ' (' . $customer['customer_code'] . ')'); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Tanggal Pesanan *</label>
                        <input type="date" name="order_date" value="<?php echo date('Y-m-d'); ?>" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Tanggal Pengiriman</label>
                        <input type="date" name="delivery_date" class="form-control">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Status Pesanan</label>
                        <select name="status" class="form-control">
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="shipped">Shipped</option>
                            <option value="delivered">Delivered</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Status Pembayaran</label>
                        <select name="payment_status" class="form-control">
                            <option value="unpaid">Unpaid</option>
                            <option value="partial">Partial</option>
                            <option value="paid">Paid</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Metode Pembayaran</label>
                        <select name="payment_method" class="form-control">
                            <option value="cash">Cash</option>
                            <option value="transfer">Transfer</option>
                            <option value="credit">Credit</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Catatan (Opsional)</label>
                    <textarea name="notes" class="form-control" rows="3" placeholder="Tambah catatan..."></textarea>
                </div>
            </div>
        </div>
        
        <!-- Order Items -->
        <div class="card mb-20">
            <div class="card-header">
                <h3>Daftar Barang</h3>
                <button type="button" class="btn btn-sm btn-primary" onclick="addItem()">
                    <i class="fas fa-plus"></i> Tambah Barang
                </button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="data-table" id="itemsTable">
                        <thead>
                            <tr>
                                <th width="50">#</th>
                                <th>Produk</th>
                                <th width="120">Kuantitas</th>
                                <th width="150">Harga Satuan</th>
                                <th width="150">Subtotal</th>
                                <th width="80">Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="itemsBody">
                            <!-- Items will be added here -->
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-right"><strong>Total:</strong></td>
                                <td id="totalAmount">Rp 0</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-right"><strong>Diskon:</strong></td>
                                <td>
                                    <input type="number" name="discount" id="discount" value="0" min="0" 
                                           class="form-control" oninput="calculateTotal()">
                                </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-right"><strong>Pajak:</strong></td>
                                <td>
                                    <input type="number" name="tax" id="tax" value="0" min="0" 
                                           class="form-control" oninput="calculateTotal()">
                                </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-right"><strong>Grand Total:</strong></td>
                                <td id="grandTotal">Rp 0</td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <input type="hidden" name="items" id="itemsData">
            </div>
        </div>
        
        <div class="form-actions">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="fas fa-save"></i> Simpan Pesanan
            </button>
            <a href="index.php" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>

<style>
#itemsTable input {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.item-row {
    transition: background 0.3s;
}

.item-row:hover {
    background: #f8f9fa;
}

.form-actions {
    display: flex;
    gap: 15px;
    padding: 20px 0;
    border-top: 1px solid #eee;
}

.btn-lg {
    padding: 12px 30px;
    font-size: 16px;
}
</style>

<script>
// Products data for autocomplete
const products = <?php echo json_encode($products); ?>;

let itemCount = 0;

function addItem(product = null) {
    itemCount++;
    const tbody = document.getElementById('itemsBody');
    const row = document.createElement('tr');
    row.className = 'item-row';
    row.id = 'item-' + itemCount;
    
    const productOptions = products.map(p => 
        `<option value="${p.id}" data-price="${p.price}" data-stock="${p.stock}">
            ${p.name} (${p.sku}) - Stock: ${p.stock}
        </option>`
    ).join('');
    
    row.innerHTML = `
        <td>${itemCount}</td>
        <td>
            <select class="form-control product-select" onchange="updatePrice(${itemCount})" required>
                <option value="">Pilih Produk</option>
                ${productOptions}
            </select>
        </td>
        <td>
            <input type="number" class="form-control quantity" value="1" min="1" 
                   oninput="updateSubtotal(${itemCount})" required>
        </td>
        <td>
            <input type="number" class="form-control price" readonly 
                   data-type="currency" oninput="updateSubtotal(${itemCount})">
        </td>
        <td>
            <input type="text" class="form-control subtotal" readonly>
        </td>
        <td>
            <button type="button" class="btn btn-sm btn-danger" onclick="removeItem(${itemCount})">
                <i class="fas fa-times"></i>
            </button>
        </td>
    `;
    
    tbody.appendChild(row);
    
    // If product is pre-selected
    if (product) {
        const select = row.querySelector('.product-select');
        select.value = product.id;
        updatePrice(itemCount);
        updateSubtotal(itemCount);
    }
    
    updateItemsData();
}

function removeItem(id) {
    const row = document.getElementById('item-' + id);
    if (row) {
        row.remove();
        updateItemsData();
        calculateTotal();
    }
}

function updatePrice(itemId) {
    const row = document.getElementById('item-' + itemId);
    const select = row.querySelector('.product-select');
    const priceInput = row.querySelector('.price');
    const quantityInput = row.querySelector('.quantity');
    
    if (select.value) {
        const selectedOption = select.options[select.selectedIndex];
        const price = selectedOption.dataset.price;
        const stock = parseInt(selectedOption.dataset.stock);
        
        priceInput.value = price;
        quantityInput.max = stock;
        
        // If current quantity exceeds stock, adjust it
        if (parseInt(quantityInput.value) > stock) {
            quantityInput.value = stock;
        }
        
        updateSubtotal(itemId);
    } else {
        priceInput.value = '';
        updateSubtotal(itemId);
    }
}

function updateSubtotal(itemId) {
    const row = document.getElementById('item-' + itemId);
    const quantity = parseInt(row.querySelector('.quantity').value) || 0;
    const price = parseInt(row.querySelector('.price').value) || 0;
    const subtotal = quantity * price;
    
    row.querySelector('.subtotal').value = formatCurrency(subtotal);
    calculateTotal();
    updateItemsData();
}

function calculateTotal() {
    let total = 0;
    const subtotalInputs = document.querySelectorAll('.subtotal');
    
    subtotalInputs.forEach(input => {
        const value = parseInt(input.value.replace(/\./g, '')) || 0;
        total += value;
    });
    
    const discount = parseInt(document.getElementById('discount').value) || 0;
    const tax = parseInt(document.getElementById('tax').value) || 0;
    const grandTotal = total - discount + tax;
    
    document.getElementById('totalAmount').textContent = formatCurrency(total);
    document.getElementById('grandTotal').textContent = formatCurrency(grandTotal);
}

function updateItemsData() {
    const items = [];
    const rows = document.querySelectorAll('.item-row');
    
    rows.forEach(row => {
        const select = row.querySelector('.product-select');
        const quantity = row.querySelector('.quantity').value;
        const price = row.querySelector('.price').value;
        const stock = select.selectedIndex >= 0 ? 
            select.options[select.selectedIndex].dataset.stock : 0;
        
        if (select.value && quantity && price) {
            items.push({
                product_id: select.value,
                product_name: select.options[select.selectedIndex].text,
                quantity: parseInt(quantity),
                price: parseInt(price),
                stock: parseInt(stock),
                subtotal: parseInt(quantity) * parseInt(price)
            });
        }
    });
    
    document.getElementById('itemsData').value = JSON.stringify(items);
}

function formatCurrency(amount) {
    return 'Rp ' + amount.toLocaleString('id-ID');
}

// Form validation
document.getElementById('orderForm').addEventListener('submit', function(e) {
    const items = JSON.parse(document.getElementById('itemsData').value || '[]');
    
    if (items.length === 0) {
        e.preventDefault();
        alert('Tambah minimal satu barang ke pesanan!');
        return false;
    }
    
    // Check stock availability
    for (const item of items) {
        if (item.quantity > item.stock) {
            e.preventDefault();
            alert(`Stok ${item.product_name} tidak mencukupi!`);
            return false;
        }
    }
    
    return true;
});

// Add one empty item on page load
document.addEventListener('DOMContentLoaded', function() {
    addItem();
});
</script>

<?php include '../../includes/footer.php'; ?>