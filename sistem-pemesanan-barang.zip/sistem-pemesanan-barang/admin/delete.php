<?php
// admin/delete.php
require_once '../config/config.php';
require_once '../auth-check.php';

if (!is_admin()) {
    header('HTTP/1.0 403 Forbidden');
    die('Akses ditolak. Hanya administrator yang dapat menghapus pesanan.');
}

if (!isset($_GET['id'])) {
    header('Location: orders/');
    exit();
}

$order_id = (int)$_GET['id'];
$db = new Database();

// Check if order exists
$order = $db->fetchOne("SELECT order_number FROM orders WHERE id = ?", [$order_id]);

if (!$order) {
    $_SESSION['error'] = 'Pesanan tidak ditemukan!';
    header('Location: orders/');
    exit();
}

// Check if confirmed
if (!isset($_GET['confirm']) || $_GET['confirm'] !== 'yes') {
    echo '<!DOCTYPE html>
    <html>
    <head>
        <title>Konfirmasi Hapus</title>
        <link rel="stylesheet" href="../css/style.css">
        <style>
            .confirm-box {
                max-width: 500px;
                margin: 100px auto;
                background: white;
                border-radius: 10px;
                padding: 30px;
                text-align: center;
                box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            }
            .confirm-box h2 {
                color: #dc3545;
                margin-bottom: 20px;
            }
            .confirm-box p {
                color: #666;
                margin-bottom: 30px;
                line-height: 1.6;
            }
            .confirm-actions {
                display: flex;
                gap: 15px;
                justify-content: center;
            }
            .btn-delete {
                background: #dc3545;
                color: white;
                padding: 10px 25px;
                border: none;
                border-radius: 5px;
                text-decoration: none;
                font-weight: 500;
            }
            .btn-cancel {
                background: #6c757d;
                color: white;
                padding: 10px 25px;
                border: none;
                border-radius: 5px;
                text-decoration: none;
                font-weight: 500;
            }
        </style>
    </head>
    <body>
        <div class="confirm-box">
            <h2><i class="fas fa-exclamation-triangle"></i> Konfirmasi Hapus</h2>
            <p>Anda akan menghapus pesanan:</p>
            <p><strong>' . htmlspecialchars($order['order_number']) . '</strong></p>
            <p>Tindakan ini tidak dapat dibatalkan. Semua data terkait pesanan ini akan dihapus permanen.</p>
            
            <div class="confirm-actions">
                <a href="delete.php?id=' . $order_id . '&confirm=yes" class="btn-delete">
                    <i class="fas fa-trash"></i> Ya, Hapus Permanen
                </a>
                <a href="orders/" class="btn-cancel">
                    <i class="fas fa-times"></i> Batal
                </a>
            </div>
        </div>
    </body>
    </html>';
    exit();
}

// Proceed with deletion
try {
    $db->beginTransaction();
    
    // Get order items to restore stock
    $items = $db->fetchAll("SELECT product_id, quantity FROM order_items WHERE order_id = ?", [$order_id]);
    
    foreach ($items as $item) {
        // Restore stock
        $db->query("UPDATE products SET stock = stock + ? WHERE id = ?", 
                   [$item['quantity'], $item['product_id']]);
    }
    
    // Delete order items
    $db->delete('order_items', 'order_id = ?', [$order_id]);
    
    // Delete order
    $db->delete('orders', 'id = ?', [$order_id]);
    
    $db->commit();
    
    $_SESSION['success'] = 'Pesanan ' . $order['order_number'] . ' berhasil dihapus!';
    
} catch (Exception $e) {
    $db->rollback();
    $_SESSION['error'] = 'Error menghapus pesanan: ' . $e->getMessage();
}

header('Location: orders/');
exit();
?>