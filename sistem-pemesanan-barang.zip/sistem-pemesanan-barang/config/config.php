<?php
// config/config.php
// Application Configuration

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Base URL - GANTI dengan URL website Anda
define('BASE_URL', 'http://localhost/sistem_pemesanan_barang/');

// Application settings
define('APP_NAME', 'Sistem Pemesanan Barang');
define('APP_VERSION', '1.0.0');
define('APP_ENV', 'development'); // development, production

// Database settings - GANTI sesuai hosting Anda
define('DB_HOST', 'localhost');
define('DB_NAME', 'sistem_pemesanan_barang');
define('DB_USER', 'root');
define('DB_PASS', '');

// Timezone
date_default_timezone_set('Asia/Jakarta');

// Error reporting
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Security
define('SESSION_TIMEOUT', 1800); // 30 menit

// File upload settings
define('UPLOAD_PATH', __DIR__ . '/../assets/uploads/');
define('MAX_FILE_SIZE', 5242880); // 5MB
define('ALLOWED_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'application/pdf']);

// Helper functions
function is_logged_in() {
    $headers = getallheaders();
    if (isset($headers['Authorization']) && $headers['Authorization'] === 'Bearer YOUR_TOKEN') {
        return true;
    }
    return false;
}


function require_login() {
    if (!is_logged_in()) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        header('Location: ' . BASE_URL . 'login.php');
        exit();
    }
}

function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function require_admin() {
    require_login();
    if (!is_admin()) {
        header('HTTP/1.0 403 Forbidden');
        die('Akses ditolak. Hanya administrator yang dapat mengakses halaman ini.');
    }
}

function redirect($url) {
    header('Location: ' . BASE_URL . $url);
    exit();
}

function flash_message($type, $message) {
    $_SESSION['flash'][$type] = $message;
}

function get_flash_message($type) {
    if (isset($_SESSION['flash'][$type])) {
        $message = $_SESSION['flash'][$type];
        unset($_SESSION['flash'][$type]);
        return $message;
    }
    return null;
}

function format_rupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function generate_order_number() {
    return 'ORD-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

function generate_customer_code() {
    return 'CUST-' . date('Ymd') . '-' . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
}

function generate_product_sku($category_id) {
    $prefix = 'PROD';
    switch($category_id) {
        case 1: $prefix = 'ELEC'; break;
        case 2: $prefix = 'CLOTH'; break;
        case 3: $prefix = 'FOOD'; break;
        case 4: $prefix = 'STN'; break;
        case 5: $prefix = 'FURN'; break;
    }
    return $prefix . '-' . date('ym') . '-' . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
}

// Include database class
require_once 'database.php';
?>