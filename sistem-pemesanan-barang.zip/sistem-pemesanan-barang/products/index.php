<?php
// products/index.php
require_once '../config/config.php';
require_once '../auth-check.php';

$db = new Database();
$page_title = 'Daftar Produk';

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Search and filter
$search = $_GET['search'] ?? '';
$category_id = $_GET['category_id'] ?? '';
$status = $_GET['status'] ?? '';
$min_price = $_GET['min_price'] ?? '';
$max_price = $_GET['max_price'] ?? '';

// Build WHERE clause
$where = [];
$params = [];

if ($search) {
    $where[] = "(p.name LIKE ? OR p.sku LIKE ? OR p.description LIKE ?)";
    $search_term = "%$search%";
    array_push($params, $search_term, $search_term, $search_term);
}

if ($category_id && $category_id !== 'all') {
    $where[] = "p.category_id = ?";
    $params[] = $category_id;
}

if ($status && $status !== 'all') {
    $where[] = "p.status = ?";
    $params[] = $status;
}

if ($min_price !== '') {
    $where[] = "p.price >= ?";
    $params[] = $min_price;
}

if ($max_price !== '') {
    $where[] = "p.price <= ?";
    $params[] = $max_price;
}

$where_clause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Get total count
$count_query = "SELECT COUNT(*) as total FROM products p $where_clause";
$count_result = $db->fetchOne($count_query, $params);
$total_products = $count_result['total'] ?? 0;
$total_pages = ceil($total_products / $limit);

// Get products with category
$query = "SELECT p.*, c.name as category_name 
          FROM products p 
          LEFT JOIN categories c ON p.category_id = c.id 
          $where_clause 
          ORDER BY p.created_at DESC 
          LIMIT $limit OFFSET $offset";

$products = $db->fetchAll($query, $params);

// Get categories for filter
$categories = $db->fetchAll("SELECT id, name FROM categories ORDER BY name");

include '../includes/header.php';
?>

<div class="container">
    <div class="page-header">
        <h1><i class="fas fa-box"></i> Daftar Produk</h1>
        <div class="header-actions">
            <a href="create.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Tambah Produk
            </a>
            <?php if (is_admin()): ?>
            <a href="import.php" class="btn btn-success">
                <i class="fas fa-file-import"></i> Import
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Filter Card -->
    <div class="card mb-20">
        <div class="card-body">
            <form method="GET" class="filter-form">
                <div class="form-row">
                    <div class="form-group">
                        <label>Pencarian</label>
                        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                               placeholder="Nama, SKU, atau deskripsi">
                    </div>
                    
                    <div class="form-group">
                        <label>Kategori</label>
                        <select name="category_id" class="form-control">
                            <option value="all">Semua Kategori</option>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo $cat['id']; ?>" 
                                <?php echo $category_id == $cat['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cat['name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="all">Semua Status</option>
                            <option value="active" <?php echo $status == 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo $status == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            <option value="discontinued" <?php echo $status == 'discontinued' ? 'selected' : ''; ?>>Discontinued</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Harga Min</label>
                        <input type="number" name="min_price" value="<?php echo $min_price; ?>" 
                               class="form-control" placeholder="Harga minimum">
                    </div>
                    
                    <div class="form-group">
                        <label>Harga Max</label>
                        <input type="number" name="max_price" value="<?php echo $max_price; ?>" 
                               class="form-control" placeholder="Harga maksimum">
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                    <a href="?" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Products Table -->
    <div class="card">
        <div class="card-header">
            <h3>Data Produk (<?php echo $total_products; ?>)</h3>
            <div class="table-actions">
                <select id="bulkAction" class="form-control">
                    <option value="">Aksi Massal</option>
                    <option value="export">Export CSV</option>
                    <option value="print">Cetak Label</option>
                    <?php if (is_admin()): ?>
                    <option value="activate">Aktifkan</option>
                    <option value="deactivate">Nonaktifkan</option>
                    <option value="delete">Hapus</option>
                    <?php endif; ?>
                </select>
                <button class="btn btn-sm btn-primary" onclick="applyBulkAction()">Terapkan</button>
            </div>
        </div>
        
        <div class="card-body">
            <?php if (empty($products)): ?>
            <div class="empty-state text-center">
                <i class="fas fa-box fa-3x text-muted mb-20"></i>
                <h3>Tidak ada produk</h3>
                <p class="text-muted">Belum ada produk yang ditambahkan.</p>
                <a href="create.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Tambah Produk Pertama
                </a>
            </div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="data-table" id="productsTable">
                    <thead>
                        <tr>
                            <th width="50">
                                <input type="checkbox" id="selectAll" onchange="toggleSelectAll()">
                            </th>
                            <th>Produk</th>
                            <th>SKU</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): 
                            $stock_class = 'text-success';
                            if ($product['stock'] <= $product['min_stock']) {
                                $stock_class = 'text-warning';
                            }
                            if ($product['stock'] == 0) {
                                $stock_class = 'text-danger';
                            }
                            
                            $status_class = 'badge-success';
                            if ($product['status'] == 'inactive') {
                                $status_class = 'badge-secondary';
                            }
                            if ($product['status'] == 'discontinued') {
                                $status_class = 'badge-danger';
                            }
                        ?>
                        <tr>
                            <td>
                                <input type="checkbox" class="product-checkbox" value="<?php echo $product['id']; ?>">
                            </td>
                            <td>
                                <div class="product-info">
                                    <?php if ($product['image']): ?>
                                    <img src="../assets/uploads/products/<?php echo $product['image']; ?>" 
                                         alt="<?php echo htmlspecialchars($product['name']); ?>"
                                         class="product-thumb">
                                    <?php else: ?>
                                    <div class="product-thumb placeholder">
                                        <i class="fas fa-box"></i>
                                    </div>
                                    <?php endif; ?>
                                    <div class="product-details">
                                        <strong><?php echo htmlspecialchars($product['name']); ?></strong>
                                        <?php if ($product['description']): ?>
                                        <p class="product-desc"><?php echo substr(htmlspecialchars($product['description']), 0, 50); ?>...</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td><code><?php echo $product['sku']; ?></code></td>
                            <td><?php echo htmlspecialchars($product['category_name'] ?? '-'); ?></td>
                            <td><strong>Rp <?php echo number_format($product['price'], 0, ',', '.'); ?></strong></td>
                            <td class="<?php echo $stock_class; ?>">
                                <strong><?php echo $product['stock']; ?> <?php echo $product['unit']; ?></strong>
                                <?php if ($product['stock'] <= $product['min_stock']): ?>
                                <br><small class="text-warning">Stok rendah!</small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo $status_class; ?>">
                                    <?php echo ucfirst($product['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="view.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-info" title="Lihat">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="edit.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <?php if (is_admin()): ?>
                                    <a href="delete.php?id=<?php echo $product['id']; ?>" 
                                       class="btn btn-sm btn-danger" 
                                       title="Hapus"
                                       onclick="return confirm('Hapus produk ini?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <nav class="pagination mt-20">
                <ul class="pagination-list">
                    <?php if ($page > 1): ?>
                    <li>
                        <a href="?page=<?php echo $page-1; ?>&<?php echo http_build_query($_GET); ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="<?php echo $i == $page ? 'active' : ''; ?>">
                        <a href="?page=<?php echo $i; ?>&<?php echo http_build_query($_GET); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                    <li>
                        <a href="?page=<?php echo $page+1; ?>&<?php echo http_build_query($_GET); ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                <div class="pagination-info">
                    Menampilkan <?php echo min($limit, count($products)); ?> dari <?php echo $total_products; ?> produk
                </div>
            </nav>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.product-info {
    display: flex;
    align-items: center;
    gap: 10px;
}

.product-thumb {
    width: 50px;
    height: 50px;
    border-radius: 5px;
    object-fit: cover;
}

.product-thumb.placeholder {
    background: #f8f9fa;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ccc;
}

.product-details {
    flex: 1;
}

.product-desc {
    font-size: 12px;
    color: #666;
    margin: 5px 0 0 0;
}

code {
    background: #f8f9fa;
    padding: 3px 6px;
    border-radius: 3px;
    font-family: monospace;
    font-size: 12px;
}
</style>

<script>
function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.product-checkbox');
    checkboxes.forEach(cb => cb.checked = selectAll.checked);
}

function getSelectedProducts() {
    const selected = [];
    document.querySelectorAll('.product-checkbox:checked').forEach(cb => {
        selected.push(cb.value);
    });
    return selected;
}

function applyBulkAction() {
    const action = document.getElementById('bulkAction').value;
    const selected = getSelectedProducts();
    
    if (selected.length === 0) {
        alert('Pilih produk terlebih dahulu!');
        return;
    }
    
    switch(action) {
        case 'export':
            exportToCSV('productsTable', 'produk_' + new Date().toISOString().split('T')[0] + '.csv');
            break;
            
        case 'print':
            // Print labels
            break;
            
        case 'activate':
        case 'deactivate':
        case 'delete':
            if (confirm(`${action.charAt(0).toUpperCase() + action.slice(1)} ${selected.length} produk terpilih?`)) {
                fetch('bulk_action.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        action: action,
                        ids: selected
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                });
            }
            break;
    }
}
</script>

<?php include '../includes/footer.php'; ?>