<?php
// products/update_api.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, PUT, PATCH');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../config/config.php';

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$db = new Database();
$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'POST' || $method == 'PUT' || $method == 'PATCH') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['id'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Product ID is required']);
        exit();
    }
    
    $product_id = (int)$data['id'];
    
    // Get current product data
    $current_product = $db->fetchOne("SELECT * FROM products WHERE id = ?", [$product_id]);
    
    if (!$current_product) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Product not found']);
        exit();
    }
    
    // Prepare update data
    $update_data = [];
    $has_changes = false;
    
    // Define fields and their comparison methods
    $fields = [
        'name' => 'string',
        'category_id' => 'int',
        'description' => 'string',
        'price' => 'float',
        'stock' => 'int',
        'min_stock' => 'int',
        'unit' => 'string',
        'status' => 'string'
    ];
    
    foreach ($fields as $field => $type) {
        if (isset($data[$field])) {
            $new_value = $data[$field];
            $current_value = $current_product[$field];
            
            // Type-specific comparison
            $is_different = false;
            
            switch ($type) {
                case 'int':
                    $is_different = (int)$new_value != (int)$current_value;
                    break;
                case 'float':
                    $is_different = (float)$new_value != (float)$current_value;
                    break;
                case 'string':
                    $is_different = trim($new_value) != trim($current_value);
                    break;
                default:
                    $is_different = $new_value != $current_value;
            }
            
            if ($is_different) {
                $update_data[$field] = $new_value;
                $has_changes = true;
            }
        }
    }
    
    // Check if stock update is valid (not negative)
    if (isset($update_data['stock']) && $update_data['stock'] < 0) {
        http_response_code(400);
        echo json_encode([
            'success' => false, 
            'message' => 'Stock cannot be negative',
            'updated' => false
        ]);
        exit();
    }
    
    // If no changes, return early
    if (!$has_changes) {
        echo json_encode([
            'success' => true,
            'message' => 'No changes detected. Update skipped.',
            'data' => $current_product,
            'updated' => false
        ]);
        exit();
    }
    
    try {
        // Add updated_at timestamp
        $update_data['updated_at'] = date('Y-m-d H:i:s');
        
        // Update product
        $affected_rows = $db->update('products', $update_data, 'id = ?', [$product_id]);
        
        if ($affected_rows > 0) {
            // Get updated product
            $updated_product = $db->fetchOne("SELECT * FROM products WHERE id = ?", [$product_id]);
            
            // Log stock changes
            if (isset($update_data['stock'])) {
                $old_stock = $current_product['stock'];
                $new_stock = $update_data['stock'];
                $difference = $new_stock - $old_stock;
                
                if ($difference != 0) {
                    $db->insert('stock_movements', [
                        'product_id' => $product_id,
                        'old_stock' => $old_stock,
                        'new_stock' => $new_stock,
                        'difference' => $difference,
                        'reason' => 'manual_update',
                        'notes' => 'Stock updated via API',
                        'user_id' => $_SESSION['user_id'],
                        'created_at' => date('Y-m-d H:i:s')
                    ]);
                }
            }
            
            // Log activity
            $db->insert('activity_logs', [
                'user_id' => $_SESSION['user_id'],
                'action' => 'product_update',
                'description' => 'Updated product: ' . $current_product['name'],
                'ip_address' => $_SERVER['REMOTE_ADDR'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT']
            ]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Product updated successfully',
                'data' => $updated_product,
                'updated' => true,
                'changes' => array_keys($update_data)
            ]);
            
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'No rows affected',
                'updated' => false
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Update failed: ' . $e->getMessage(),
            'updated' => false
        ]);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>