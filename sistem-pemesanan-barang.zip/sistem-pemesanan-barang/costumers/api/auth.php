<?php
// customers/api/auth.php - REST API for authentication
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../../config/config.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (isset($data['action'])) {
            switch ($data['action']) {
                case 'login':
                    handleLogin($data);
                    break;
                case 'check':
                    checkAuth();
                    break;
                default:
                    jsonResponse(['error' => 'Invalid action'], 400);
            }
        } else {
            jsonResponse(['error' => 'No action specified'], 400);
        }
        break;
        
    case 'OPTIONS':
        // Handle preflight requests
        break;
        
    default:
        jsonResponse(['error' => 'Method not allowed'], 405);
}

function handleLogin($data) {
    if (!isset($data['username']) || !isset($data['password'])) {
        jsonResponse(['error' => 'Username and password required'], 400);
        return;
    }
    
    $db = new Database();
    
    try {
        $user = $db->fetchOne(
            "SELECT id, username, password, full_name, email, role 
             FROM users 
             WHERE username = ? OR email = ?",
            [$data['username'], $data['username']]
        );
        
        if ($user && password_verify($data['password'], $user['password'])) {
            // Start session
            session_start();
            
            // Set session data
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['email'] = $user['email'];
            
            // Update last login
            $db->update('users', 
                ['last_login' => date('Y-m-d H:i:s')], 
                'id = ?', 
                [$user['id']]
            );
            
            // Generate token (simple session token)
            $token = bin2hex(random_bytes(32));
            $_SESSION['api_token'] = $token;
            
            jsonResponse([
                'success' => true,
                'message' => 'Login successful',
                'token' => $token,
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'full_name' => $user['full_name'],
                    'role' => $user['role'],
                    'email' => $user['email']
                ]
            ]);
            
        } else {
            jsonResponse(['error' => 'Invalid credentials'], 401);
        }
        
    } catch (Exception $e) {
        error_log('Login error: ' . $e->getMessage());
        jsonResponse(['error' => 'Internal server error'], 500);
    }
}

function checkAuth() {
    session_start();
    
    if (isset($_SESSION['user_id'])) {
        jsonResponse([
            'authenticated' => true,
            'user' => [
                'id' => $_SESSION['user_id'],
                'username' => $_SESSION['username'],
                'full_name' => $_SESSION['full_name'],
                'role' => $_SESSION['role']
            ]
        ]);
    } else {
        jsonResponse(['authenticated' => false]);
    }
}

function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data);
    exit();
}
?>