<?php
// customers/orders.php - Customer's order history
require_once '../config/config.php';
require_once '../auth-check.php';

$db = new Database();
$page_title = 'Pesanan Saya';

// Get customer ID from session (assuming customer is logged in)
$customer_id = $_SESSION['customer_id'] ?? null;

if (!$customer_id) {
    $_SESSION['error'] = 'Silakan login sebagai pelanggan untuk melihat pesanan.';
    header('Location: ../login.php');
    exit();
}

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Get total orders for this customer
$total_orders = $db->fetchOne("SELECT COUNT(*) as total FROM orders WHERE customer_id = ?", [$customer_id])['total'];
$total_pages = ceil($total_orders / $limit);

// Get orders
$query = "SELECT o.*, 
                 COUNT(oi.id) as item_count,
                 SUM(oi.subtotal) as total_amount
          FROM orders o 
          LEFT JOIN order_items oi ON o.id = oi.order_id 
          WHERE o.customer_id = ? 
          GROUP BY o.id 
          ORDER BY o.created_at DESC 
          LIMIT $limit OFFSET $offset";

$orders = $db->fetchAll($query, [$customer_id]);

include '../includes/header.php';
?>

<div class="container">
    <div class="page-header">
        <h1><i class="fas fa-shopping-cart"></i> Pesanan Saya</h1>
        <p>Riwayat pesanan Anda</p>
    </div>

    <!-- Orders List -->
    <div class="card">
        <div class="card-header">
            <h3>Daftar Pesanan (<?php echo $total_orders; ?>)</h3>
        </div>
        
        <div class="card-body">
            <?php if (empty($orders)): ?>
            <div class="empty-state text-center">
                <i class="fas fa-shopping-cart fa-3x text-muted mb-20"></i>
                <h3>Belum ada pesanan</h3>
                <p class="text-muted">Anda belum membuat pesanan apapun.</p>
                <a href="../products/" class="btn btn-primary">
                    <i class="fas fa-shopping-bag"></i> Lihat Katalog
                </a>
            </div>
            <?php else: ?>
            <div class="orders-list">
                <?php foreach ($orders as $order): 
                    $status_class = '';
                    switch($order['status']) {
                        case 'pending': $status_class = 'warning'; break;
                        case 'processing': $status_class = 'info'; break;
                        case 'shipped': $status_class = 'primary'; break;
                        case 'delivered': $status_class = 'success'; break;
                        case 'cancelled': $status_class = 'danger'; break;
                        default: $status_class = 'secondary';
                    }
                    
                    $payment_class = '';
                    switch($order['payment_status']) {
                        case 'paid': $payment_class = 'success'; break;
                        case 'partial': $payment_class = 'warning'; break;
                        case 'unpaid': $payment_class = 'danger'; break;
                        default: $payment_class = 'secondary';
                    }
                ?>
                <div class="order-card">
                    <div class="order-header">
                        <div class="order-info">
                            <h4>
                                <a href="order_detail.php?id=<?php echo $order['id']; ?>">
                                    <?php echo $order['order_number']; ?>
                                </a>
                            </h4>
                            <div class="order-meta">
                                <span class="order-date">
                                    <i class="fas fa-calendar"></i>
                                    <?php echo date('d F Y', strtotime($order['order_date'])); ?>
                                </span>
                                <span class="order-items">
                                    <i class="fas fa-box"></i>
                                    <?php echo $order['item_count']; ?> item
                                </span>
                            </div>
                        </div>
                        <div class="order-status">
                            <span class="badge badge-<?php echo $status_class; ?>">
                                <?php echo ucfirst($order['status']); ?>
                            </span>
                            <span class="badge badge-<?php echo $payment_class; ?>">
                                <?php echo ucfirst($order['payment_status']); ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="order-body">
                        <div class="order-details">
                            <div class="detail-item">
                                <strong>Total:</strong>
                                <span class="amount">Rp <?php echo number_format($order['grand_total'], 0, ',', '.'); ?></span>
                            </div>
                            <div class="detail-item">
                                <strong>Metode Pembayaran:</strong>
                                <span><?php echo ucfirst($order['payment_method']); ?></span>
                            </div>
                            <?php if ($order['notes']): ?>
                            <div class="detail-item">
                                <strong>Catatan:</strong>
                                <span><?php echo htmlspecialchars($order['notes']); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="order-actions">
                            <a href="order_detail.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-info">
                                <i class="fas fa-eye"></i> Detail
                            </a>
                            <a href="../admin/orders/print.php?id=<?php echo $order['id']; ?>" target="_blank" class="btn btn-sm btn-primary">
                                <i class="fas fa-print"></i> Invoice
                            </a>
                            <?php if ($order['status'] == 'pending'): ?>
                            <a href="cancel_order.php?id=<?php echo $order['id']; ?>" 
                               class="btn btn-sm btn-danger"
                               onclick="return confirm('Batalkan pesanan ini?')">
                                <i class="fas fa-times"></i> Batalkan
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <nav class="pagination mt-20">
                <ul class="pagination-list">
                    <?php if ($page > 1): ?>
                    <li>
                        <a href="?page=<?php echo $page-1; ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="<?php echo $i == $page ? 'active' : ''; ?>">
                        <a href="?page=<?php echo $i; ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                    <li>
                        <a href="?page=<?php echo $page+1; ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.orders-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.order-card {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 20px;
    border-left: 4px solid #667eea;
}

.order-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid #dee2e6;
}

.order-info h4 {
    margin-bottom: 5px;
}

.order-info h4 a {
    color: #333;
    text-decoration: none;
}

.order-info h4 a:hover {
    color: #667eea;
}

.order-meta {
    display: flex;
    gap: 15px;
    font-size: 13px;
    color: #666;
}

.order-meta i {
    margin-right: 5px;
}

.order-status {
    display: flex;
    gap: 5px;
}

.order-body {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.order-details {
    flex: 1;
}

.detail-item {
    margin-bottom: 8px;
    display: flex;
    gap: 10px;
}

.detail-item strong {
    min-width: 120px;
    color: #666;
}

.detail-item .amount {
    color: #28a745;
    font-weight: 600;
}

.order-actions {
    display: flex;
    gap: 5px;
}
</style>

<?php include '../includes/footer.php'; ?>