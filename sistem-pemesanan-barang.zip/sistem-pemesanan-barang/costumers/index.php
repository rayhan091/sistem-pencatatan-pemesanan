<?php
// customers/index.php
require_once '../config/config.php';
require_once '../auth-check.php';

$db = new Database();
$page_title = 'Daftar Pelanggan';

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Search and filter
$search = $_GET['search'] ?? '';
$type = $_GET['type'] ?? '';
$status = $_GET['status'] ?? '';

// Build WHERE clause
$where = [];
$params = [];

if ($search) {
    $where[] = "(c.name LIKE ? OR c.company LIKE ? OR c.email LIKE ? OR c.phone LIKE ? OR c.customer_code LIKE ?)";
    $search_term = "%$search%";
    array_push($params, $search_term, $search_term, $search_term, $search_term, $search_term);
}

if ($type && $type !== 'all') {
    $where[] = "c.type = ?";
    $params[] = $type;
}

if ($status && $status !== 'all') {
    $where[] = "c.status = ?";
    $params[] = $status;
}

$where_clause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Get total count
$count_query = "SELECT COUNT(*) as total FROM customers c $where_clause";
$count_result = $db->fetchOne($count_query, $params);
$total_customers = $count_result['total'] ?? 0;
$total_pages = ceil($total_customers / $limit);

// Get customers
$query = "SELECT c.*, 
                 COUNT(o.id) as total_orders,
                 SUM(o.grand_total) as total_spent
          FROM customers c 
          LEFT JOIN orders o ON c.id = o.customer_id 
          $where_clause 
          GROUP BY c.id 
          ORDER BY c.created_at DESC 
          LIMIT $limit OFFSET $offset";

$customers = $db->fetchAll($query, $params);

include '../includes/header.php';
?>

<div class="container">
    <div class="page-header">
        <h1><i class="fas fa-users"></i> Daftar Pelanggan</h1>
        <div class="header-actions">
            <a href="create.php" class="btn btn-primary">
                <i class="fas fa-user-plus"></i> Tambah Pelanggan
            </a>
            <?php if (is_admin()): ?>
            <a href="import.php" class="btn btn-success">
                <i class="fas fa-file-import"></i> Import
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Filter Card -->
    <div class="card mb-20">
        <div class="card-body">
            <form method="GET" class="filter-form">
                <div class="form-row">
                    <div class="form-group">
                        <label>Pencarian</label>
                        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                               placeholder="Nama, perusahaan, email, telepon, atau kode">
                    </div>
                    
                    <div class="form-group">
                        <label>Tipe</label>
                        <select name="type" class="form-control">
                            <option value="all">Semua Tipe</option>
                            <option value="personal" <?php echo $type == 'personal' ? 'selected' : ''; ?>>Personal</option>
                            <option value="company" <?php echo $type == 'company' ? 'selected' : ''; ?>>Perusahaan</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="all">Semua Status</option>
                            <option value="active" <?php echo $status == 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo $status == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                    <a href="?" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Customers Table -->
    <div class="card">
        <div class="card-header">
            <h3>Data Pelanggan (<?php echo $total_customers; ?>)</h3>
            <div class="table-actions">
                <select id="bulkAction" class="form-control">
                    <option value="">Aksi Massal</option>
                    <option value="export">Export CSV</option>
                    <option value="print">Cetak Daftar</option>
                    <?php if (is_admin()): ?>
                    <option value="activate">Aktifkan</option>
                    <option value="deactivate">Nonaktifkan</option>
                    <option value="delete">Hapus</option>
                    <?php endif; ?>
                </select>
                <button class="btn btn-sm btn-primary" onclick="applyBulkAction()">Terapkan</button>
            </div>
        </div>
        
        <div class="card-body">
            <?php if (empty($customers)): ?>
            <div class="empty-state text-center">
                <i class="fas fa-users fa-3x text-muted mb-20"></i>
                <h3>Tidak ada pelanggan</h3>
                <p class="text-muted">Belum ada pelanggan yang ditambahkan.</p>
                <a href="create.php" class="btn btn-primary">
                    <i class="fas fa-user-plus"></i> Tambah Pelanggan Pertama
                </a>
            </div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="data-table" id="customersTable">
                    <thead>
                        <tr>
                            <th width="50">
                                <input type="checkbox" id="selectAll" onchange="toggleSelectAll()">
                            </th>
                            <th>Pelanggan</th>
                            <th>Kontak</th>
                            <th>Tipe</th>
                            <th>Total Pesanan</th>
                            <th>Total Belanja</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($customers as $customer): 
                            $status_class = $customer['status'] == 'active' ? 'badge-success' : 'badge-secondary';
                            $type_class = $customer['type'] == 'company' ? 'badge-primary' : 'badge-info';
                        ?>
                        <tr>
                            <td>
                                <input type="checkbox" class="customer-checkbox" value="<?php echo $customer['id']; ?>">
                            </td>
                            <td>
                                <div class="customer-info">
                                    <div class="customer-avatar">
                                        <?php echo strtoupper(substr($customer['name'], 0, 1)); ?>
                                    </div>
                                    <div class="customer-details">
                                        <strong><?php echo htmlspecialchars($customer['name']); ?></strong>
                                        <?php if ($customer['company']): ?>
                                        <p class="customer-company"><?php echo htmlspecialchars($customer['company']); ?></p>
                                        <?php endif; ?>
                                        <small class="customer-code"><?php echo $customer['customer_code']; ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <?php if ($customer['email']): ?>
                                <div class="contact-item">
                                    <i class="fas fa-envelope"></i>
                                    <?php echo htmlspecialchars($customer['email']); ?>
                                </div>
                                <?php endif; ?>
                                <?php if ($customer['phone']): ?>
                                <div class="contact-item">
                                    <i class="fas fa-phone"></i>
                                    <?php echo htmlspecialchars($customer['phone']); ?>
                                </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo $type_class; ?>">
                                    <?php echo $customer['type'] == 'company' ? 'Perusahaan' : 'Personal'; ?>
                                </span>
                            </td>
                            <td>
                                <div class="text-center">
                                    <strong><?php echo $customer['total_orders']; ?></strong>
                                    <br>
                                    <small>pesanan</small>
                                </div>
                            </td>
                            <td>
                                <strong>Rp <?php echo number_format($customer['total_spent'] ?? 0, 0, ',', '.'); ?></strong>
                            </td>
                            <td>
                                <span class="badge <?php echo $status_class; ?>">
                                    <?php echo $customer['status'] == 'active' ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="view.php?id=<?php echo $customer['id']; ?>" class="btn btn-sm btn-info" title="Lihat">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="edit.php?id=<?php echo $customer['id']; ?>" class="btn btn-sm btn-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <?php if (is_admin()): ?>
                                    <a href="delete.php?id=<?php echo $customer['id']; ?>" 
                                       class="btn btn-sm btn-danger" 
                                       title="Hapus"
                                       onclick="return confirm('Hapus pelanggan ini?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <nav class="pagination mt-20">
                <ul class="pagination-list">
                    <?php if ($page > 1): ?>
                    <li>
                        <a href="?page=<?php echo $page-1; ?>&<?php echo http_build_query($_GET); ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="<?php echo $i == $page ? 'active' : ''; ?>">
                        <a href="?page=<?php echo $i; ?>&<?php echo http_build_query($_GET); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                    
                    <?php if ($page < $total_pages): ?>
                    <li>
                        <a href="?page=<?php echo $page+1; ?>&<?php echo http_build_query($_GET); ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                <div class="pagination-info">
                    Menampilkan <?php echo min($limit, count($customers)); ?> dari <?php echo $total_customers; ?> pelanggan
                </div>
            </nav>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.customer-info {
    display: flex;
    align-items: center;
    gap: 10px;
}

.customer-avatar {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 600;
}

.customer-details {
    flex: 1;
}

.customer-company {
    font-size: 12px;
    color: #666;
    margin: 2px 0;
}

.customer-code {
    font-size: 11px;
    color: #999;
    font-family: monospace;
}

.contact-item {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 13px;
    margin-bottom: 3px;
}

.contact-item i {
    width: 16px;
    color: #666;
}
</style>

<script>
function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.customer-checkbox');
    checkboxes.forEach(cb => cb.checked = selectAll.checked);
}

function getSelectedCustomers() {
    const selected = [];
    document.querySelectorAll('.customer-checkbox:checked').forEach(cb => {
        selected.push(cb.value);
    });
    return selected;
}

function applyBulkAction() {
    const action = document.getElementById('bulkAction').value;
    const selected = getSelectedCustomers();
    
    if (selected.length === 0) {
        alert('Pilih pelanggan terlebih dahulu!');
        return;
    }
    
    switch(action) {
        case 'export':
            exportToCSV('customersTable', 'pelanggan_' + new Date().toISOString().split('T')[0] + '.csv');
            break;
            
        case 'activate':
        case 'deactivate':
        case 'delete':
            if (confirm(`${action.charAt(0).toUpperCase() + action.slice(1)} ${selected.length} pelanggan terpilih?`)) {
                fetch('bulk_action.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        action: action,
                        ids: selected
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                });
            }
            break;
    }
}
</script>

<?php include '../includes/footer.php'; ?>