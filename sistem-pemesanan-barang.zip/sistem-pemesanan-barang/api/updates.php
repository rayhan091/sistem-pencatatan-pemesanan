<?php
// api/update.php - Generic update API for any table
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, PUT, PATCH');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../config/config.php';

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$db = new Database();
$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'POST' || $method == 'PUT' || $method == 'PATCH') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate required parameters
    if (empty($data['table']) || empty($data['id'])) {
        http_response_code(400);
        echo json_encode([
            'success' => false, 
            'message' => 'Table name and ID are required',
            'required' => ['table', 'id']
        ]);
        exit();
    }
    
    $table = $data['table'];
    $id = (int)$data['id'];
    $updates = $data['updates'] ?? [];
    
    // Validate table name (security)
    $allowed_tables = ['products', 'customers', 'categories', 'orders', 'users'];
    if (!in_array($table, $allowed_tables)) {
        http_response_code(403);
        echo json_encode([
            'success' => false, 
            'message' => 'Table not allowed for update',
            'allowed_tables' => $allowed_tables
        ]);
        exit();
    }
    
    // Get current data
    $current_data = $db->fetchOne("SELECT * FROM $table WHERE id = ?", [$id]);
    
    if (!$current_data) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Record not found']);
        exit();
    }
    
    // Define allowed fields for each table
    $table_fields = [
        'products' => ['name', 'category_id', 'price', 'stock', 'min_stock', 'unit', 'status', 'description'],
        'customers' => ['name', 'company', 'email', 'phone', 'address', 'type', 'status'],
        'categories' => ['name', 'description', 'icon', 'color'],
        'orders' => ['status', 'payment_status', 'payment_method', 'notes', 'delivery_date'],
        'users' => ['full_name', 'email', 'role', 'status']
    ];
    
    $allowed_fields = $table_fields[$table] ?? [];
    
    // Filter and validate updates
    $filtered_updates = [];
    $has_changes = false;
    
    foreach ($updates as $field => $value) {
        if (!in_array($field, $allowed_fields)) {
            continue; // Skip unauthorized fields
        }
        
        // Check if value is different
        $current_value = $current_data[$field] ?? null;
        
        if (is_numeric($value) && is_numeric($current_value)) {
            // Numeric comparison
            if ((float)$value != (float)$current_value) {
                $filtered_updates[$field] = $value;
                $has_changes = true;
            }
        } else {
            // String comparison
            if (trim($value) !== trim((string)$current_value)) {
                $filtered_updates[$field] = $value;
                $has_changes = true;
            }
        }
    }
    
    // If no changes, return early
    if (!$has_changes) {
        echo json_encode([
            'success' => true,
            'message' => 'No changes detected. Update skipped.',
            'data' => $current_data,
            'updated' => false,
            'table' => $table,
            'id' => $id
        ]);
        exit();
    }
    
    try {
        // Add updated_at timestamp if field exists
        $table_columns = $db->fetchAll("SHOW COLUMNS FROM $table");
        $has_updated_at = false;
        
        foreach ($table_columns as $column) {
            if ($column['Field'] == 'updated_at') {
                $has_updated_at = true;
                break;
            }
        }
        
        if ($has_updated_at) {
            $filtered_updates['updated_at'] = date('Y-m-d H:i:s');
        }
        
        // Perform update
        $affected_rows = $db->update($table, $filtered_updates, 'id = ?', [$id]);
        
        if ($affected_rows > 0) {
            // Get updated data
            $updated_data = $db->fetchOne("SELECT * FROM $table WHERE id = ?", [$id]);
            
            // Log activity
            $changes_summary = [];
            foreach ($filtered_updates as $field => $value) {
                if ($field != 'updated_at') {
                    $old_value = $current_data[$field] ?? 'null';
                    $changes_summary[] = "$field: $old_value → $value";
                }
            }
            
            $db->insert('activity_logs', [
                'user_id' => $_SESSION['user_id'],
                'action' => 'api_update',
                'description' => "Updated $table #$id. Changes: " . implode(', ', $changes_summary),
                'ip_address' => $_SERVER['REMOTE_ADDR'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT']
            ]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Update successful',
                'data' => $updated_data,
                'updated' => true,
                'changes' => $changes_summary,
                'affected_fields' => array_keys($filtered_updates)
            ]);
            
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Update failed - no rows affected',
                'updated' => false
            ]);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Update failed: ' . $e->getMessage(),
            'updated' => false,
            'error_details' => $e->getTraceAsString()
        ]);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>